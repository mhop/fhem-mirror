
#ifndef _LEDCHANNEL_H
#define _LEDCHANNEL_H

#include "Arduino.h"

class ledChannel
{
  public:
    ledChannel( int pin );

    byte value() const;
    void setValue( byte );

    bool dimUp();
    bool dimDown();

    // TODO: gamma, min- u. max level, 12/16 bit?

  private:
    byte _value;
    float dim;

  private:
    int pin;

  private:  // Disable copy constructor and operator=
    ledChannel( const ledChannel & );
    ledChannel& operator=( const ledChannel & );
};

#endif
