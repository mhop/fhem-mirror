
#ifndef CONFIG_H
#define CONFIG_H

//#define ENABLE_IR
//#define ENABLE_DMX
//#define ENABLE_REPEATER
//#define ENABLE_BRIGHTNESS

#ifdef ENABLE_BRIGHTNESS
#  define BRI_PIN A1
#endif

#endif
