
#ifndef CONFIG_H
#define CONFIG_H

//#define USE_SOFT_PWM

#define ENABLE_IR_RECV
//#define ENABLE_IR_SEND
#define ENABLE_DMX
//#define ENABLE_REPEATER
#define ENABLE_LED_POWER
//#define ENABLE_BRIGHTNESS

//#define MAX_CHANNELS                   3

#define LED_DEBUG

#ifdef ENABLE_LED_POWER
#  define LED_POWER_PIN A1
#endif

#ifdef ENABLE_BRIGHTNESS
#  define BRI_PIN A2
#endif

#endif
