
#ifndef _COMMANDS_H
#define _COMMANDS_H
                                         // t fade time in sec;
                                         // r reg
                                         // iiiiiiii ir cmd
enum COMMANDS { CMD_NOOP = 0x00,
                RET_OK = 0x05,
                RET_ERR = 0x06,
                CMD_On = 0x10,           // RRGGBBW1W2tt
                CMD_Off = 0x11,          // tttt
                CMD_DimUp = 0x12,        //
                CMD_DimDown = 0x13,      //
                CMD_OnForTimer = 0x14,   // tttt
                CMD_Toggle = 0x20,
                CMD_GetIR = 0x30,        // r
                CMD_SetIR = 0x31,        // riiiiiiii
                CMD_LearnIR = 0x32,      // r
                CMD_GetFade = 0x40,      // r
                CMD_SetFade = 0x41,      // rRRGGBBtt
                CMD_StartFade = 0x42,    // rr
                CMD_SendIR = 0x50,       // ttbbbbbbb
                CMD_RESET = 0xFF,
};

const void setCommand(byte rId,byte *command);

#endif
