
#ifndef _FADE_H
#define _FADE_H

#define TIMER_OFF ~0L

void fadeTo( int secs, byte r, byte g, byte b );

struct Fade
{
  public:
    long duration;
    unsigned long start;

    int notify_timeout;
    unsigned long last_notify;

    byte to[3];
    int diff[3];

    inline Fade() : duration(0) {start = TIMER_OFF;};
};

extern Fade fade;

extern byte current_fade_reg;
extern byte fade_start;
extern byte fade_end;

inline void fadeStop() {fade.start = TIMER_OFF;};
inline bool isFading() {return fade.start != TIMER_OFF;};
inline bool inFade() {return fade_start != fade_end;};
#endif
