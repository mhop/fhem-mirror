
#ifndef _EEPROM_H
#define _EEPROM_H

enum {
  STATE_OFF = 0,
  STATE_BRI,
  STATE_COLOR,
  STATE_AUTOSAVE,
};
struct powerOnState {
  byte state;
  byte bri;
  byte rgb[3];
};
#define EEPROM_POWER_ON_STATE   EEPROM_FIRST_CUSTOM

#ifdef ENABLE_REPEATER
extern byte maxRepeaterHop;
#endif
#define EEPROM_CONFIG_REPEATER  EEPROM_POWER_ON_STATE+sizeof(powerOnState)

struct irCmd{
  unsigned long ir_cmd;
  byte cmd[6];
};
extern irCmd ir_cmds[0x10];
#define EEPROM_CONFIG_IR  EEPROM_CONFIG_REPEATER+1

struct fadeStep{
  byte rgb[3];
  byte secs;
};
extern fadeStep fade_steps[0x10];
#define EEPROM_CONFIG_FADE  EEPROM_CONFIG_IR+sizeof(ir_cmds)

#define EEPROM_CONFIG_DMX  EEPROM_CONFIG_FADE+sizeof(fade_steps)

#endif
