// Help.h

#ifndef _HELP_h
#define _HELP_h

#define NOHELP

#ifndef NOHELP

#include "Arduino.h"

class Help {
 private:

 public:
   static void Show();
};

#endif

#endif

