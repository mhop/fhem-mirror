// Help.h

#ifndef _HELP_h
#define _HELP_h

//#define NOHELP	// comment out to globally disable help

#ifndef NOHELP

#include "Arduino.h"

class Help {
 private:

 public:
   static void Show();
};

#endif	// NOHELP

#endif	// _HELP_h

