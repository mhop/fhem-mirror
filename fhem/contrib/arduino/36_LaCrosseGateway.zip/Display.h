
#ifndef _DISPLAY_h
#define _DISPLAY_h

#include "Arduino.h"
#include "StateManager.h"
#include "OLED.h"

#define Y1 18
#define Y2 34
#define Y3 50

class Display {
protected:
  OLED m_display;
  bool m_isConnected;
  StateManager *m_stateManager;
  unsigned long m_lastUpdate;
  unsigned int m_currentProgress;
  unsigned int m_maxProgress;

public:
  Display();
  bool Begin(StateManager *stateManager);
  void Print(String text, byte line = 1, OLED::Alignments alignment = OLED::Alignments::Left);
  void Command(String command);
  bool IsConnected();
  void Handle();
  void Clear();
  void SetWifiFlag(bool flag);
  void SetFhemFlag(bool flag);
  void SetAddonFlag(bool flag);
  void SetRSSI(int rssi);
  void SetLED(bool show);
  void ShowProgress(unsigned int maxValue, String message);
  void MoveProgress();
  void HideProgress();

};


#endif

