#ifndef __LM75_h__
#define __LM75_h__

#include "Arduino.h"
#include "I2CBase.h"

#define LM75_TEMPERATURE_REGISTER 0

class LM75 : public I2CBase {
public:
  LM75();
  bool TryInitialize(byte address);
  float GetTemperature();

private:


};

#endif
