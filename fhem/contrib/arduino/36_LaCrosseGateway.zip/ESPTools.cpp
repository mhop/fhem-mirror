#include "ESPTools.h"

ESPTools::ESPTools(byte ledPin) {
  m_ledPin = ledPin;
  m_ledEnabled = true;
  m_blinkDuration = 5;
}

void ESPTools::SwitchLed(boolean on, bool force) {
  if (m_ledEnabled || force) {
    pinMode(m_ledPin, OUTPUT);
    digitalWrite(m_ledPin, !on);
  }
}

void ESPTools::Blink(byte ct, bool force) {
  if (m_ledEnabled || force) {
    for (int i = 0; i < ct; i++) {
      SwitchLed(true, force);
      delay(m_blinkDuration);
      SwitchLed(false, force);
      if (ct > 1) {
        delay(m_blinkDuration);
      }
    }
  }

}

void ESPTools::SetBlinkDuration(uint duration) {
  m_blinkDuration = duration;
}

void ESPTools::EnableLED(bool enable) {
  m_ledEnabled = enable;

  if (!m_ledEnabled) {
    SwitchLed(false);
  }

}

