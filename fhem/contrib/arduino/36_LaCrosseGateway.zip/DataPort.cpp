#include "DataPort.h"


DataPort::DataPort() : m_server(0) {

}

void DataPort::Begin(uint port) {
  m_enabled = true;

  m_server = WiFiServer(port);
  m_server.begin();
  m_server.setNoDelay(true);
}

void DataPort::AddPayload(String payload) {
  if (m_enabled &&  m_queue.Count() <= 10) {
    m_queue.Push(payload);
  }
}

void DataPort::Send(String data) {
  if (m_enabled && m_client && !m_client.available()) {
    m_client.println(data);    
  }
}

void DataPort::SetDebugMode(boolean mode) {
  m_debug = mode;
}

bool DataPort::Handle(CommandCallbackType* callback) {
  bool result = false;
  
  if(m_enabled) {
    if (!m_client.connected()) {
      m_client.stop();
    }
    if (!m_client) {
      m_client = m_server.available();
      if (m_client) {
        m_client.setNoDelay(true);
        m_client.setTimeout(10);
        m_initialized = false;
        m_lastMillis = millis() + 1000;

        if (m_debug) {
          Serial.println("Client connected with:");
          Serial.print("IP=");
          Serial.println(m_client.remoteIP());
          Serial.print("Port=");
          Serial.println(m_client.remotePort());
        }

      }
    }
    else {
      if (m_client.available()) {
        String request = m_client.readString();
        if (m_debug) {
          Serial.print(millis()); Serial.print(": ");
          Serial.print("received: ");
          Serial.print(request);
        }
        if (!request.startsWith("GET ")) {
          if (callback != NULL) {
            String result = callback(request);
            if (result.length() > 0) {
              Send(result);
            }
          }
        }
        m_client.flush();
      }
      else {
        // After 50 days, millis() will overflow to zero 
        if (millis() < m_lastMillis) {
          m_lastMillis = 0;
        }
        if (millis() > m_lastMillis + 250) {
          if (!m_initialized ) {
            if (callback != NULL) {
              m_client.println("");
              delay(1000);
              callback("v");
            }
            m_initialized = true;
          }
          else {
            while (!m_queue.IsEmpty()) {
              String pl = m_queue.Pop();
              Send(pl);
              delay(10);
            }
            result = true;
          }

          m_lastMillis = millis();

        }

      }

    }
  }
  
  return result;
}

