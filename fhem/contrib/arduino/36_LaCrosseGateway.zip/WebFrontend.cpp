#include "WebFrontend.h"
#include <EEPROM.h>
#include "Settings.h"
#include "HTML.h"
#include "OTAUpdate.h"


WebFrontend::WebFrontend(int port) : m_webserver(port) {
  m_port = port;
}

void WebFrontend::SetDebugMode(boolean mode) {
  m_debug = mode;
}

void WebFrontend::Begin(StateManager *stateManager) {
  m_stateManager = stateManager;
  m_webserver.begin();
}

String WebFrontend::GetNavigation() {
  String result = "";
  result += "<a href='/'>Home</a>&nbsp;&nbsp;";
  result += "<a href='setup'>Setup</a>&nbsp;&nbsp;";
  result += "<a href='ota'>OTA-Update</a>&nbsp;&nbsp;";
  ////result += "&nbsp;&nbsp;&nbsp;&nbsp;<a href='reset'>Reset</a>&nbsp;&nbsp;";

  result += "<br><br>";
  
  return result;
}

void WebFrontend::Handle() {
  WiFiClient webclient = m_webserver.available();
  if (webclient) {
    unsigned long timeOutStart = millis();
    while (!webclient.available() && millis() < timeOutStart + 500){
      delay(1);
    }

    if (webclient.available()) {
      String request = webclient.readStringUntil('\r');
      webclient.flush();
      int s1 = request.indexOf(' ');
      int s2 = request.indexOf(' ', s1 +1);
      if (s1 != -1 && s2 != -1) {
        String result = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n<!DOCTYPE HTML>\r\n<html>";
        result += "<p>LaCrosseGateway V";
        result += m_stateManager->GetVersion();
        result += "</p>";
        
        request = request.substring(s1 + 1, s2);
        
        if (request == "/") {
          result += GetNavigation();
          result += m_stateManager->GetHTML();
        }
        else if (request == "/reset") {
          ESP.restart();
        }
        else if (request ==  "/ota") {
          result += GetNavigation();

          Settings settings;
          settings.Read();

          result += "<form method='get' action='ota_start'>";
          result += "Server:&nbsp";
          result += settings.Get("otaServer", "");
          result += "<br>Port:&nbsp";
          result += settings.Get("otaPort", "");
          result += "<br>url:&nbsp";
          result += settings.Get("otaURL", "");

          result += "<br><br> <input type='submit' Value='Update and restart' > </form>";
        }
        else if (request.startsWith("/ota_start")) {
          result += GetNavigation();
          result += "OTA-firmware update result:<br>";
          result += OTAUpdate::Start();
        }
        else if (request == "/state") {
          result = m_stateManager->GetXML();
        }
        else if (request == "/setup") {
          result += GetNavigation();

          Settings settings;
          settings.Read();
         
          result += "<form method='get' action='save'> <table>";
        
          // ctSSID
          result += "<tr> <td> <label>SSID: </label> </td> <td> <input name='ctSSID' size='80' maxlength='32' Value='";
          result += settings.Get("ctSSID", "");
          result += "'> </td> </tr>";
         
          // ctPASS
          result += "<tr> <td> <label>Password: </label> </td> <td> <input name='ctPASS' size='80' maxlength='63' Value='";
          result += settings.Get("ctPASS", "");
          result += "'> </td> </tr>";

          result += "<tr><td></td><td><br>If IP, mask or gateway is empty, DHCP will be used</td></tr>";

          // staticIP
          result += "<tr> <td> <label>IP-Address: </label> </td> <td> <input name='staticIP' size='80' maxlength='15' Value='";
          result += settings.Get("staticIP", ""); 
          result += "'> </td> </tr>";
          
          // staticMask
          result += "<tr> <td> <label>Netmask: </label> </td> <td> <input name='staticMask' size='80' maxlength='15' Value='";
          result += settings.Get("staticMask", "");
          result += "'> </td> </tr>";
          
          // staticGW
          result += "<tr> <td> <label>Gateway: </label> </td> <td> <input name='staticGW' size='80' maxlength='15' Value='";
          result += settings.Get("staticGW", "");
          result += "'> </td> </tr>";
          
          // HostName
          result += "<tr> <td> <label>Hostname: </label> </td> <td> <input name='HostName' size='80' maxlength='63' Value='";
          result += settings.Get("HostName", "LaCrosseGateway");
          result += "'> </td> </tr>";

          // Data ports
          result += "<tr> <td> <label>Data ports: </label> </td> <td>";
          result += "<input name='DataPort1' maxlength='5' Value='";
          result += settings.Get("DataPort1", "81");
          result += "'>&nbsp;";
          result += "<input name='DataPort2' maxlength='5' Value='";
          result += settings.Get("DataPort2", "");
          result += "'>&nbsp;";
          result += "<input name='DataPort3' maxlength='5' Value='";
          result += settings.Get("DataPort3", "");
          result += "'>&nbsp;";
          result += "</td> </tr>";

          // KVInterval
          result += "<tr><td></td><td><br>Use 'off' to disable KV-transmission</td></tr>";
          result += "<tr> <td> <label>KV-Interval: </label> </td> <td> <input name='KVInterval' size='80' maxlength='3' Value='";
          result += settings.Get("KVInterval", "10");
          result += "'> </td> </tr>";

          // KVIdentity
          result += "<tr> <td> <label>KV-Identity: </label> </td> <td> <input name='KVIdentity' size='80' maxlength='20' Value='";
          result += settings.Get("KVIdentity", String(ESP.getChipId()));
          result += "'> </td> </tr>";
          
          result += "<tr><td></td><td><br>OTA update</td></tr>";

          // OTA-Server
          result += "<tr> <td> <label>OTA-Server: </label> </td> <td> <input name='otaServer' size='80' maxlength='40' Value='";
          result += settings.Get("otaServer", "");
          result += "'> </td> </tr>";

          // OTA-Port
          result += "<tr> <td> <label>OTA-Port: </label> </td> <td> <input name='otaPort' size='80' maxlength='5' Value='";
          result += settings.Get("otaPort", "");
          result += "'> </td> </tr>";

          // OTA-url
          result += "<tr> <td> <label>OTA-url: </label> </td> <td> <input name='otaURL' size='80' maxlength='80' Value='";
          result += settings.Get("otaURL", "");
          result += "'> </td> </tr>";


          result += "</table> <br> <input type='submit' Value='Save and restart' > </form>";
          
        }
        else if (request.startsWith("/save?") ) {
          Settings settings;
          request = request.substring(6) + "&";

          while (request.indexOf("&") != -1) {
            int pos = request.indexOf('&');
            String oneSetting = request.substring(0, pos);
            request = request.substring(pos + 1);

            int pos2 = oneSetting.indexOf("=");
            String key = oneSetting.substring(0, pos2);
            String value = HTML::Unescape(oneSetting.substring(pos2 + 1));
            settings.Add(key, value);
          }
          
          settings.Dump();
          settings.Write();
          ESP.restart();

        }
        else {
          result = "HTTP/1.1 404 Not Found\r\n\r\n";
        }     

        if (result.indexOf("<html>") != -1) {
          result += "</html>\r\n\r\n";
        }

        // Send the response to the client        
        webclient.print(result);
      }
    }

  }


}

