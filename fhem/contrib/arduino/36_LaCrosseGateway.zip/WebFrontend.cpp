#include "WebFrontend.h"
#include <EEPROM.h>
#include "Settings.h"
#include "HTML.h"
#include "OTAUpdate.h"
#include "Help.h"
#include "ESP8266WiFiType.h"
#include "ESPTools.h"

String WifiModeToString(WiFiMode_t mode) {
  switch (mode) {
  case WiFiMode_t::WIFI_AP:
    return "Accespoint";
    break;
  case WiFiMode_t::WIFI_AP_STA:
    return "Accespoint + Station";
    break;
  case WiFiMode_t::WIFI_OFF:
    return "Off";
    break;
  case WiFiMode_t::WIFI_STA:
    return "Station";
    break;
  default:
    return "";
    break;
  }
}

const char on_log[] PROGMEM = ""
"<script>\n"
"  function sendCommand() {\n"
"    var cmd = document.getElementById('commandText').value;\n"
"    var request = new XMLHttpRequest();\n"
"    request.open('GET', 'command?cmd=' + encodeURIComponent(cmd), true);\n"
"    request.send();\n"
"  };\n"
"  function clearList(what) {\n"
"    document.getElementById(what + 'Div').innerHTML = '';\n"
"    filter(what);\n"
"  };\n"
"  function filter(what) {\n"
"    var el = document.getElementById(what + 'DivFilter');\n"
"    var text0 = el.value.toLowerCase();\n"
"    var elements = document.getElementsByClassName(what + 'Line');\n"
"    var names = '';\n"
"    var ct = 0;\n"
"    for (var i = 0; i < elements.length; i++) {\n"
"      if (elements[i].innerHTML.toLowerCase().indexOf(text0) == -1) {\n"
"        elements[i].style.display = 'none';\n"
"      }\n"
"      else {\n"
"        elements[i].style.display = 'block';\n"
"        ct++;\n"
"      }\n"
"    }\n"
"    document.getElementById(what + 'RowCount').innerHTML = ct + \" rows\";\n"
"  };\n"
"  function run() {\n"
"    var el = document.getElementById('logDivFilter');\n"
"    el.onkeyup = function (evt) {\n"
"      filter('log');\n"
"    };\n"
"    var el = document.getElementById('dataDivFilter');\n"
"    el.onkeyup = function (evt) {\n"
"      filter('data');\n"
"    };\n"
"    getLogData();\n"
"  };\n"
"  function getLogData() {\n"
"    if (document.getElementById('enabled').checked == true) {\n"
"      var request = new XMLHttpRequest();\n"
"      request.onreadystatechange = function () {\n"
"        if (this.readyState == 4 && this.status == 200 && this.responseText != null && this.responseText != '') {\n"
"          var lines = this.responseText.split('\\n');\n"
"          for (var i = 0; i < lines.length; i++) {\n"
"            var txt = lines[i];\n"
"            if (txt != '') {\n"
"              if (txt == 'SYS: ***CLEARLOG***') {\n"
"                clearList('data');\n"
"                clearList('log');\n"
"              } else {\n"
"                var targetDiv = 'logDiv';\n"
"                var scrollCheckBox = 'scrollLogDiv';\n"
"                var prefix = 'log';\n"
"                if (txt.startsWith('DATA:')) {\n"
"                  prefix = 'data';\n"
"                  targetDiv = 'dataDiv';\n"
"                  scrollCheckBox = 'scrollDataDiv';\n"
"                  txt = txt.substring(5);\n"
"                }\n"
"                if (txt.startsWith('SYS:')) {\n"
"                  txt = txt.substring(4);\n"
"                }\n"
"                txt = new Date().toLocaleTimeString('de-DE') + ': ' + txt;\n"
"                document.getElementById(targetDiv).innerHTML += \"<div class='\" + prefix + \"Line'>\" + txt + '</div>';\n"
"                filter(prefix);\n"
"                if (document.getElementById(scrollCheckBox).checked == true) {\n"
"                  var objDiv = document.getElementById(targetDiv);\n"
"                  objDiv.scrollTop = objDiv.scrollHeight;\n"
"                }\n"
"              }\n"
"            }\n"
"          }\n"
"        }\n"
"      };\n"
"      request.open('GET', 'getLogData?nc=' + Math.random(), true);\n"
"      request.send();\n"
"    }\n"
"    setTimeout('getLogData()', 500);\n"
"  };\n"
"</script>\n"
"<body onload='run()'>\n"
"  Command: <input id='commandText' size='100' onkeydown=\"if (event.keyCode == 13) sendCommand()\">\n"
"  <button type='button' onclick=\"sendCommand();\">Send</button>\n"
"  &nbsp;&nbsp;&nbsp;\n"
"  <input type='checkbox' id='enabled' value='true' checked>Enable logging\n"
"  <br><br>\n"
"  <i>LGW to FHEM:</i>\n"
"  <input type='checkbox' id='scrollDataDiv' value='true' checked> Scroll\n"
"  <button type='button' onclick=\"clearList('data');\">Clear</button>\n"
"  Filter:\n"
"  <input id='dataDivFilter'>\n"
"  <span id='dataRowCount'></span>\n"
"  <div id='dataDiv' style='height: 250px; border:1px solid black; overflow:scroll;'></div>\n"
"  <br><i>Debug log:</i>\n"
"  <input type='checkbox' id='scrollLogDiv' value='true' checked> Scroll\n"
"  <button type='button' onclick=\"clearList('log');\">Clear</button>\n"
"  Filter:\n"
"  <input text='text' id='logDivFilter'>\n"
"  <span id='logRowCount'></span>\n"
"  <div id='logDiv' style='height: 250px; border:1px solid black; overflow:scroll;'></div>\n"
"</body>\n"
;

WebFrontend::WebFrontend(int port) : m_webserver(port) {
  m_port = port;
  m_password = "";
  m_commandCallback = nullptr;
  m_hardwareCallback = nullptr;
}

ESP8266WebServer *WebFrontend::WebServer() {
  return &m_webserver;
}

void WebFrontend::SetCommandCallback(CommandCallbackType callback) {
  m_commandCallback = callback;
}

void WebFrontend::SetHardwareCallback(HardwareCallbackType callback) {
  m_hardwareCallback = callback;
}

void WebFrontend::SetPassword(String password) {
  m_password = password;
}

bool WebFrontend::IsAuthentified() {
  bool result = false;
  if (m_password.length() > 0) {
    if (m_webserver.hasHeader("Cookie")) {
      String cookie = m_webserver.header("Cookie");
      if (cookie.indexOf("ESPSESSIONID=1") != -1) {
        result = true;
      }
    }
    if (!result) {
      String header = "HTTP/1.1 301 OK\r\nLocation: /login\r\nCache-Control: no-cache\r\n\r\n";
      m_webserver.sendContent(header);
    }
  }
  else {
    result = true;
  }

  return result;
}

void WebFrontend::Begin(StateManager *stateManager, Logger *logger) {
  m_stateManager = stateManager;
  m_logger = logger;
  
  const char *headerKeys[] = { "User-Agent", "Cookie" };
  m_webserver.collectHeaders(headerKeys, sizeof(headerKeys) / sizeof(char*));

  m_webserver.on("/", [this]() {
    if (IsAuthentified()) {
      String result;
      result += GetTop();
      result += GetNavigation();
      result += m_stateManager->GetHTML();
      result += GetBottom();
      m_webserver.send(200, "text/html", result);
    }
  });

  m_webserver.on("/reset", [this]() {
    if (IsAuthentified()) {
      m_webserver.send(200, "text/html", GetRedirectToRoot());
      ESP.restart();
    }
  });

  m_webserver.on("/command", [this]() {
    if (IsAuthentified()) {
      if (m_commandCallback != NULL) {
        String command = m_webserver.arg("cmd");
        m_logger->println("Command from frontend: '" + command + "'");
        m_commandCallback(command);
        m_webserver.send(200, "text/html", "OK");
      }
    }
  });

  m_webserver.on("/state", [this]() {
    String result;
    result += m_stateManager->GetXML();
    m_webserver.send(200, "text/xml", result);
  });

  m_webserver.on("/help", [this]() {
    if (IsAuthentified()) {
      String result;
      result += GetTop();
      result += GetNavigation();
      result += FPSTR(help);
      result += GetBottom();
      m_webserver.send(200, "text/html", result);
    }
  });

  m_webserver.on("/hardware", [this]() {
    if (IsAuthentified()) {
      String result;
      result += GetTop();
      result += GetNavigation();
      result += "<table>";

      result += BuildHardwareRow("ESP8266&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", "present :-)&nbsp;&nbsp;&nbsp;", "Core:&nbsp;" + String(ESP.getCoreVersion()) + "&nbsp;&nbsp;SDK:&nbsp;" + String(ESP.getSdkVersion()) + "&nbsp;&nbsp;free heap:&nbsp;" + String(ESP.getFreeHeap()) + "&nbsp;&nbsp;Reset:&nbsp;" + ESP.getResetReason() + "&nbsp;&nbsp;->&nbsp;" + ESP.getResetInfo());
      result += BuildHardwareRow("WiFi", String(WiFi.RSSI()) + " dBm", "Mode: " + WifiModeToString(WiFi.getMode()) + "&nbsp;&nbsp;&nbsp;Time to connect: " + String(m_stateManager->GetWiFiConnectTime(), 1) + " s");
      if (m_hardwareCallback != nullptr) {
        String rawData = m_hardwareCallback();
        result += "<tr><td>";
        rawData.replace("\t", "</td><td>");
        rawData.replace("\n", "</td></tr><tr><td>");
        rawData.replace(" ", "&nbsp;");
        result += rawData;
        result += "</td></tr></table>";
      }

      result += GetBottom();
      m_webserver.send(200, "text/html", result);
    }
  });

  m_webserver.on("/ota", [this]() {
    if (IsAuthentified()) {
      String result;
      result += GetTop();
      result += GetNavigation();
      Settings settings;
      settings.Read();
      result += F("<form method='get' action='ota_start'>");
      result += F("Server:&nbsp");
      result += settings.Get("otaServer", "");
      result += F("<br>Port:&nbsp");
      result += settings.Get("otaPort", "");
      result += F("<br>url:&nbsp");
      result += settings.Get("otaURL", "");
      result += F("<br><br> <input type='submit' Value='Update and restart' > </form>");
      result += GetBottom();
      m_webserver.send(200, "text/html", result);
    }
  });

  m_webserver.on("/ota_start", [this]() {
    if (IsAuthentified()) {
      m_webserver.send(200, "text/html", OTAUpdate::Start());
    }
  });

  m_webserver.on("/save", [this]() {
    if (IsAuthentified()) {
      Settings settings;

      bool gotUseWiFi = false;
      for (byte i = 0; i < m_webserver.args(); i++) {
        settings.Add(m_webserver.argName(i), m_webserver.arg(i));
        if (m_webserver.argName(i) == "UseWiFi") {
          gotUseWiFi = true;
        }
      }
      if (!gotUseWiFi) {
        settings.Add("UseWiFi", "false");
      }

      bool saveIt = true;
      if (m_webserver.hasArg("frontPass") && m_webserver.hasArg("frontPass2")) {
        String fp1 = m_webserver.arg("frontPass");
        String fp2 = m_webserver.arg("frontPass2");
        if (!fp1.equals(fp2)) {
          String content = GetTop();
          content += F("<div align=center>");
          content += F("<br><br><h2><font color='red'>");
          content += F("Passwords do nat match</font></h2>");
          content += F("</div>");
          content += GetBottom();
          m_webserver.send(200, "text/html", content);
          saveIt = false;
        }
      }

      if (m_webserver.hasArg("HostName")) {
        String hostname = m_webserver.arg("HostName");
        for (byte i = 0; i < hostname.length(); i++) {
          char ch = (char)hostname[i];
          if (!((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch == '-' || ch == '_')) {
            saveIt = false;
            String content = GetTop();
            content += F("<div align=center>");
            content += F("<br><br><h2><font color='red'>");
            content += F("Allowed characters for hostname: 0...9, a...z, A...Z, - and _</font></h2>");
            content += F("</div>");
            content += GetBottom();
            m_webserver.send(200, "text/html", content);
            break;
          }

        }
      }
      
      if (saveIt) {
        String info = settings.Write();
        m_webserver.send(200, "text/html", GetRedirectToRoot("Settings saved<br>" + info));
        ESP.restart();
      }

    }
  });

  m_webserver.on("/setup", [this]() {
    if (IsAuthentified()) {
      String result;
      Settings settings;
      settings.Read();

      result += GetTop();
      result += GetNavigation();

      result += F("<form method='get' action='save'> <table>");

      result += F("<tr><td></td><td><br>Third parameter is the timeout. After timeout seconds, it will try to connect to SSID2 (if defined)</td></tr>");

      // ctSSID ctPASS
      result += F("<tr> <td> <label>SSID / Password: </label> </td> <td> <input name='ctSSID' size='44' maxlength='32' Value='");
      result += settings.Get("ctSSID", "");
      result += F("'>");
      result += F("&nbsp;&nbsp;<input type='password' name='ctPASS' size='54' maxlength='63' Value='");
      result += settings.Get("ctPASS", "");
      result += F("'>&nbsp;&nbsp;<input name='Timeout1' size='6' maxlength='4' Value='");
      result += settings.Get("Timeout1", "15");
      result += F("'> </td> </tr>");
      
      // ctSSID2 ctPASS2
      result += F("<tr> <td> <label>SSID2 / Password2: </label> </td> <td> <input name='ctSSID2' size='44' maxlength='32' Value='");
      result += settings.Get("ctSSID2", "");
      result += F("'>");
      result += F("&nbsp;&nbsp;<input type='password' name='ctPASS2' size='54' maxlength='63' Value='");
      result += settings.Get("ctPASS2", "");
      result += F("'>&nbsp;&nbsp;<input name='Timeout2' size='6' maxlength='4' Value='");
      result += settings.Get("Timeout2", "15");
      result += F("'> </td> </tr>");

      // Frontend Password
      result += F("<tr> <td> <label>Frontend password: </label> </td> <td>");
      result += F("<input name='frontPass' type='password' size='30' maxlength='60' Value='");
      result += settings.Get("frontPass", "");
      result += F("'> Retype: ");
      result += F("<input name='frontPass2' type='password' size='30' maxlength='60' Value='");
      result += settings.Get("frontPass2", "");
      result += F("'> (if empty, no login is required)</td> </tr>");

      result += F("<tr><td></td><td><br>DHCP will be used, in case of one of the fields IP, mask or gateway remains empty</td></tr>");

      // staticIP, staticMask, staticGW, 
      result += F("<tr> <td> <label>IP-Address: </label> </td> <td> <input name='staticIP' size='27' maxlength='15' Value='");
      result += settings.Get("staticIP", "");
      result += F("'><label>&nbsp;&nbsp;Netmask: </label> <input name='staticMask' size='27' maxlength='15' Value='");
      result += settings.Get("staticMask", "");
      result += F("'><label>&nbsp;&nbsp;Gateway: </label> <input name='staticGW' size='27' maxlength='15' Value='");
      result += settings.Get("staticGW", "");
      result += F("'> </td> </tr>");

      // HostName, startup-delay
      result += F("<tr> <td> <label>Hostname: </label> </td> <td> <input name='HostName' size='27' maxlength='63' Value='");
      result += settings.Get("HostName", "LaCrosseGateway");
      result += F("'><label>&nbsp;&nbsp;Startup-delay (s): </label> <input name='StartupDelay' size='5' maxlength='4' Value='");
      result += settings.Get("StartupDelay", "0");
      result += F("'> </td> </tr>");

      // Internal sensors
      result += F("<tr> <td> <label>Internal sensors:</label> </td> <td> <label>ID: </label> <input name='ISID' size='5' maxlength='4' Value='");
      result += settings.Get("ISID", "0");
      result += F("'><label>&nbsp;&nbsp;Altitude: </label> <input name='Altitude' size='5' maxlength='4' Value='");
      result += settings.Get("Altitude", "0");
      result += F("'><label>&nbsp;&nbsp;Temperature-correction: </label> <input name='CorrT' size='5' maxlength='5' Value='");
      result += settings.Get("CorrT", "0");
      result += F("'><label>&nbsp;&nbsp;Humidity-correction: </label> <input name='CorrH' size='5' maxlength='5' Value='");
      result += settings.Get("CorrH", "0");
      result += F("'> </td> </tr>");
     
      // Data ports
      result += F("<tr> <td> <label>Data ports: </label> </td> <td>");
      result += F("<input name='DataPort1' maxlength='5' size='10' Value='");
      result += settings.Get("DataPort1", "81");
      result += F("'>&nbsp;");
      result += F("<input name='DataPort2' maxlength='5' size='10' Value='");
      result += settings.Get("DataPort2", "");
      result += F("'>&nbsp;");
      result += F("<input name='DataPort3' maxlength='5' size='10' Value='");
      result += settings.Get("DataPort3", "");
      result += F("'>&nbsp;");
      result += F("&nbsp;<label>Serial bridge port: </label><input name='SerialBridgePort' maxlength='5' size='10' Value='");
      result += settings.Get("SerialBridgePort", "");
      result += F("'>&nbsp;<label>baud: </label><input name='SerialBridgeBaud' maxlength='6' size='10' Value='");
      result += settings.Get("SerialBridgeBaud", "57600");
      result += F("'>&nbsp;");
      result += F("</td> </tr>");

      // Flags
      result += F("<tr><td> <label>Flags: </label> </td><td>");
      result += F("<input name='UseWiFi' type='checkbox' value='true' "); result += settings.Get("UseWiFi", "true") == "true" ? "checked" : ""; result += F(">Use WiFi&nbsp;&nbsp;&nbsp;");
      result += F("<input name='Is750Clone' type='checkbox' value='true' "); result += settings.Get("Is750Clone", "") == "true" ? "checked" : ""; result += F(">SC16IS750-Clone&nbsp;&nbsp;&nbsp;");
      result += F("<input name='UseMDNS' type='checkbox' value='true' "); result += settings.Get("UseMDNS", "") == "true" ? "checked" : ""; result += F("> Use MDNS&nbsp;&nbsp;&nbsp;");
      result += F("<br></td></tr>");

      // MCP23008
      result += F("<tr><td> <label>MCP23008: </label> </td><td>");
      result += GetMCPCombos(&settings, 1);
      result += F("<br>");
      result += GetMCPCombos(&settings, 2);
      result += F("</td></tr>");

      // OLED
      result += F("<tr><td></td><td><br>Possible values: 'on', 'off' or the number of seconds until 'off' and in the second parameter a mode like th, thp, ...</td></tr>");
      result += F("<tr> <td> <label>OLED start: </label> </td> <td>on/off: <input name='oledStart' size='10' maxlength='6' Value='");
      result += settings.Get("oledStart", "on");
      result += F("'>&nbsp;mode: ");
      result += F("<input name='oledMode' size='12' maxlength='16' Value='");
      result += settings.Get("oledMode", "");
      result += F("'>&nbsp;&nbsp;");
      result += F("<input name='oled13' type='checkbox' value='true' ");
      result += settings.Get("oled13", "false") == "true" ? "checked" : ""; 
      result += F(">1.3\"");
      result += F("</td> </tr>");

      // KVInterval and KVIdentity
      result += F("<tr><td></td><td><br>Use 'off' to disable KV-transmission</td></tr>");
      result += F("<tr> <td> <label>KV-Interval: </label> </td> <td> <input name='KVInterval' size='50' maxlength='3' Value='");
      result += settings.Get("KVInterval", "10");
      result += F("'> <label>KV-Identity: </label> <input name='KVIdentity' size='50' maxlength='20' Value='");
      result += settings.Get("KVIdentity", String(ESP.getChipId()));
      result += F("'> </td> </tr>");

      result += F("<tr><td></td><td><br>OTA update</td></tr>");

      // OTA-Server
      result += F("<tr> <td> <label>OTA-Server: </label> </td> <td> <input name='otaServer' size='120' maxlength='40' Value='");
      result += settings.Get("otaServer", "");
      result += F("'> </td> </tr>");

      // OTA-Port
      result += F("<tr> <td> <label>OTA-Port: </label> </td> <td> <input name='otaPort' size='120' maxlength='5' Value='");
      result += settings.Get("otaPort", "");
      result += F("'> </td> </tr>");

      // OTA-url
      result += F("<tr> <td> <label>OTA-url: </label> </td> <td> <input name='otaURL' size='120' maxlength='80' Value='");
      result += settings.Get("otaURL", "");
      result += F("'> </td> </tr>");

      // PCA301
      result += F("<tr><td></td><td><br>PCA301 (normally no need to change it)</td></tr>");
      result += F("<tr> <td> <label>Plugs: </label> </td> <td> <input name='PCA301Plugs' size='120' maxlength='160' Value='");
      result += settings.Get("PCA301Plugs", "");
      result += F("'> </td> </tr>");

      // Flags
      result += F("<tr><td></td><td><br>Only for development</td></tr>");
      result += F("<tr> <td> <label>Flags: </label> </td> <td> <input name='Flags' size='90' maxlength='80' Value='");
      result += settings.Get("Flags", "");
      result += F("'> </td> </tr>");

      result += F("</table> <br> <input type='submit' Value='Save and restart' > </form>");

      result += GetBottom();

      m_webserver.send(200, "text/html", result);
    }
  });
  
  m_webserver.on("/getLogData", [this]() {
    String data = "";
    if (m_logger->IsEnabled()) {
      while (m_logger->Available()) {
        data += m_logger->Pop() + "\n";
      }
    }
    else {
      data += F("SYS: ***CLEARLOG***\n");
      data += F("DATA:Logger is disabled\n");
      data += F("SYS:Logger is disabled\n");
    }

    m_webserver.send(200, "text/html", data);
  });

  m_webserver.on("/log", [this]() {
    if (IsAuthentified()) {
      String result;
      result += GetTop();
      result += GetNavigation();

      result += FPSTR(on_log);

      result += GetBottom();

      m_webserver.send(200, "text/html", result);
    }
  });

  m_webserver.on("/login", [this]() {
    String msg;
    if (m_webserver.hasArg("DISCONNECT")) {
      m_webserver.sendContent(F("HTTP/1.1 301 OK\r\nSet-Cookie: ESPSESSIONID=0\r\nLocation: /login\r\nCache-Control: no-cache\r\n\r\n"));
      return;
    }
    if (m_webserver.hasArg("PASSWORD")) {
      if (m_webserver.arg("PASSWORD") == m_password) {
        m_webserver.sendContent(F("HTTP/1.1 301 OK\r\nSet-Cookie: ESPSESSIONID=1\r\nLocation: /\r\nCache-Control: no-cache\r\n\r\n"));
        return;
      }
      msg = "Login failed";
    }
    String content = F("<html><body><form action='/login' method='POST'>");
    content += F("<DIV ALIGN=CENTER>");
    content += F("<br><br><h2>LaCrosseGateway V");
    content += m_stateManager->GetVersion();
    content += F("</h2>");
    content += F("Password: <input type='password' name='PASSWORD'>&nbsp;&nbsp;");
    content += F("<input type='submit' name='SUBMIT' value='Login'></form>");
    content += F("<br><br><h2> <font color='red'>");
    content += msg;
    content += F("</font></h2>");
    content += F("</div>");
    content += F("</body></html>");
    m_webserver.send(200, "text/html", content);
  });

  m_webserver.onNotFound([this](){
    m_webserver.send(404, "text/plain", "Not Found");
  });

  m_webserver.begin();
}

String WebFrontend::GetNavigation() {
  String result = "";
  result += F("<a href='/'>Home</a>&nbsp;&nbsp;");
  result += F("<a href='setup'>Setup</a>&nbsp;&nbsp;");
  result += F("<a href='hardware'>Hardware</a>&nbsp;&nbsp;");
  result += F("<a href='ota'>OTA-Update</a>&nbsp;&nbsp;");
  result += F("<a href='log'>Log</a>&nbsp;&nbsp;");
  result += F("<a href='help'>Help</a>&nbsp;&nbsp;");
  if (m_password.length() > 0) {
    result += F("<a href='login?DISCONNECT=YES'>Logout</a>&nbsp;&nbsp;");
  }
  result += F("<a href='reset'>Reboot</a>&nbsp;&nbsp;");
  result += F("<br><br>");
  
  return result;
}

String WebFrontend::GetDisplayName() {
  String result;
  result += m_stateManager->GetHostname();
  result += " (";
  result += WiFi.localIP().toString();
  result += ")";
  return result;
}

String WebFrontend::GetTop() {
  String result;
  result += F("<!DOCTYPE HTML><html>");
  result += F("<meta charset='utf-8'/>");
  result += "<head><title>";
  result += GetDisplayName();
  result += "</title></head>";
  result += F("<p>LaCrosseGateway V");
  result += m_stateManager->GetVersion();
  result += "&nbsp;&nbsp;&nbsp;";
  result += GetDisplayName();
  result += F("</p>");
  return result;
}

String WebFrontend::GetBottom() {
  String result;
  result += F("</html>");
  return result;
}

String WebFrontend::GetRedirectToRoot(String message) {
  String result;
  result += F("<html><head><meta http-equiv='refresh' content='5; URL=/'></head><body>");
  result += message;
  result += F("<br><br>Reboot, please wait a moment ...</body></html>");
  return result;
}

String GetOption(String option, String defaultValue) {
  String result = "";

  result += F("<option value='");
  result += option;
  if (defaultValue == option) {
    result += F("' selected>");
  }
  else {
    result += F("'>");
  }
  result += option;
  result += F("</option>");

  return result;
}

String WebFrontend::GetIOCombo(byte nbr, String value) {
  String result = "";
  result += F("<label>IO ");
  result += String(nbr);
  result += F(":</label>&nbsp;");
  result += F("<select name='IO");
  result += String(nbr);
  result += F("' style='width:130px'>");

  result += GetOption("Input", value);
  result += GetOption("Output", value);
  result += GetOption("OLED Off", value);
  result += GetOption("OLED On", value);
  result += GetOption("OLED mode=s", value);
  result += GetOption("OLED mode=t", value);
  result += GetOption("OLED mode=h", value);
  result += GetOption("OLED mode=th", value);
  result += GetOption("OLED mode=thp", value);
  result += GetOption("OLED mode=thps", value);

  result += F("</select>&nbsp;&nbsp;");

  return result;
}

String WebFrontend::GetMCPCombos(Settings *settings, byte part) {
  String result = "";

  if (part == 1) {
    result += GetIOCombo(0, settings->Get("IO0", "Input")) + "&nbsp;" + GetIOCombo(1, settings->Get("IO1", "Input")) + "&nbsp;" + GetIOCombo(2, settings->Get("IO2", "Input")) + "&nbsp;" + GetIOCombo(3, settings->Get("IO3", "Input"));
  }
  else {
    result += GetIOCombo(4, settings->Get("IO4", "Input")) + "&nbsp;" + GetIOCombo(5, settings->Get("IO5", "Input")) + "&nbsp;" + GetIOCombo(6, settings->Get("IO6", "Input")) + "&nbsp;" + GetIOCombo(7, settings->Get("IO7", "Input"));
  }
  
  return result;
}


String WebFrontend::BuildHardwareRow(String text1, String text2, String text3) {
  return "<tr><td>" + text1 + "</td><td>" + text2 + "</td><td>" + text3 + "</td></tr>";
}

void WebFrontend::Handle() {
  m_webserver.handleClient();
}

