#include "CapacitiveLevelFrame.h"

bool CapacitiveLevelFrame::m_debug = false;

bool CapacitiveLevelFrame::TryHandleData(byte *data) {
  String fhemString = GetFhemDataString(data);

  if(fhemString.length() > 0) {
    Serial.println(fhemString);
  }

  return fhemString.length() > 0;
}

bool CapacitiveLevelFrame::IsValidDataRate(unsigned long dataRate) {
  return dataRate == 8842ul || dataRate == 9579ul || dataRate == 17241ul;
}

uint16_t CapacitiveLevelFrame::CalculateCRC16(byte *data, byte len) {
  byte x;
  uint16_t crc = 0xFFFF;

  while(len--) {
    x = crc >> 8 ^ *data++;
    x ^= x >> 4;
    crc = (crc << 8) ^ ((uint16_t)(x << 12)) ^ ((uint16_t)(x << 5)) ^ ((uint16_t)x);
  }
  return crc;
}

void CapacitiveLevelFrame::SetDebugMode(boolean mode) {
  m_debug = mode;
}

String CapacitiveLevelFrame::GetFhemDataString(byte *data) {
  String fhemString = "";

  struct Frame frame;
  DecodeFrame(data, &frame);
  if(frame.IsValid) {
    fhemString = BuildFhemDataString(&frame);
  }

  return fhemString;
}


// =====================================================================================================
// ===== T O  D O ======================================================================================
// =====================================================================================================

void CapacitiveLevelFrame::EncodeFrame(struct Frame *frame, byte *bytes) {
  for(int i = 0; i < FRAME_LENGTH; i++) { bytes[i] = 0; }

  // Start and ID
  bytes[0] |= FRAME_HEADER << 4;
  bytes[0] |= frame->ID;

  // Temperature
  float temp = frame->Temperature + 40.0;
  bytes[1] |= (int)(temp / 10);
  bytes[2] |= ((int)temp % 10) << 4;
  bytes[2] |= (int)((int)(temp * 10) % 10);

  // Voltage
  bytes[3] |= ((int)frame->Voltage % 10) << 4;
  bytes[3] |= (int)((int)(frame->Voltage * 10) % 10);

  // Frequency
  bytes[4] = (byte)(frame->Frequency >> 24);
  bytes[5] = (byte)(frame->Frequency >> 16);
  bytes[6] = (byte)(frame->Frequency >> 8);
  bytes[7] = (byte)(frame->Frequency & 0xFF);
 
  // Debug
  bytes[8] = frame->Debug1;
  bytes[9] = frame->Debug2;
  bytes[10] = frame->Debug3;
  bytes[11] = frame->Debug4;

  // CRC
  uint16_t crc16 = CalculateCRC16(bytes, FRAME_LENGTH - 2);
  bytes[FRAME_LENGTH - 2] = (byte)(crc16 >> 8);
  bytes[FRAME_LENGTH - 1] = (byte)(crc16 & 0xFF);
}

void CapacitiveLevelFrame::DecodeFrame(byte *data, struct Frame *frame){
  frame->IsValid = true;
  frame->CRC = data[FRAME_LENGTH -2] << 8 | data[FRAME_LENGTH - 1];
  if (frame->CRC != CalculateCRC16(data, FRAME_LENGTH - 2)) {
    if (m_debug) { 
      Serial.println("## CRC WRONG ##"); 
    }
    frame->IsValid = false;
  }

  frame->ID = (data[0] & 0x0F);

  frame->Header = (data[0] & 0xF0) >> 4;
  if (frame->Header != FRAME_HEADER) {
    if (m_debug) { Serial.println("No valid start"); }
    frame->IsValid = false;
  }

  frame->Temperature = (data[1] & 0xF) * 10;
  frame->Temperature += ((data[2] & 0xF0) >> 4);
  frame->Temperature += (data[2] & 0xF) * 0.1;
  frame->Temperature -= 40;

  frame->Voltage = (data[3] & 0xF0) >> 4;
  frame->Voltage += (data[3] & 0x0F) * 0.1;

  frame->Frequency = (uint32_t)data[8] << 24;
  frame->Frequency += (uint32_t)data[9] << 16;
  frame->Frequency += (uint32_t)data[10] << 8;
  frame->Frequency += data[11];

  frame->Debug1 = data[8];
  frame->Debug2 = data[9];
  frame->Debug3 = data[10];
  frame->Debug4 = data[11];


  // Check if the data can be valid
  if (frame->Temperature < -40.0 || frame->Temperature > 60.0) {
    frame->IsValid = false;
    if (m_debug) {
      Serial.print("No valid Temperature: ");
      Serial.println(frame->Temperature);
    }
  }
  if (frame->Voltage < 0.0 || frame->Voltage > 13.0) {
    frame->IsValid = false;
    if (m_debug) {
      Serial.print("No valid Voltage: ");
      Serial.println(frame->Voltage);
    }
  }
}

String CapacitiveLevelFrame::AnalyzeFrame(byte *data) { 
  // Show the raw data bytes
  String result = "CapacitiveLevelSender [";
  for(int i = 0; i < FRAME_LENGTH; i++) {
    result += String(data[i], HEX);
    result += " ";
  }
  result += "]";

  struct Frame frame;
  DecodeFrame(data, &frame);
  result += AnalyzeFrame(&frame);

  return result;
}

String CapacitiveLevelFrame::AnalyzeFrame(Frame *frame) {
  String result;

  // Check CRC
  if (!frame->IsValid) {
    result += "CRC:WRONG";
  }
  else {
    result += "CRC:OK";
  }
  // Start
  result += " S:";
  result += String(frame->Header, HEX);

  // Sensor ID
  result += " ID:";
  result += String(frame->ID, HEX);

  // Temperature
  result += " Temp:";
  result += frame->Temperature;

  // Voltage
  result += " Volt:";
  result += frame->Voltage;

  // Frequency
  result += " Freq.:";
  result += frame->Frequency;

  // Debug
  result += " Debug:";
  result += frame->Debug1;
  result += " ";
  result += frame->Debug2;
  result += " ";
  result += frame->Debug3;
  result += " ";
  result += frame->Debug4;

  // CRC
  result += " CRC:";
  result += String((byte)(frame->CRC >> 8), HEX);
  result += " ";
  result += String((byte)(frame->CRC & 0xFF), HEX);
  
  return result;
}

String CapacitiveLevelFrame::BuildFhemDataString(struct Frame *frame) {
  // Format
  // 
  // OK CL 10  60   4 191   0   1 226  65      = 6,0V  21,5�C       123456 Hz
  // OK CL 10  57   4 251 139  21 137 203      = 5,7V  27,5�C   2333444555 Hz
  // OK CL ID VVV T1T T2T F1F F2F F3F F4F
  //
  // CL:  Fix "Capacitive Level"
  // ID:  Sensor ID (0...15)
  // VVV: Voltage * 10
  // T1T: Temp. * 10 + 1000 MSB
  // T2T: Temp. * 10 + 1000 LSB
  // F1F: Freq. >>24
  // F2F: Freq. >>16
  // F3F: Freq. >>8
  // F4F: Freq. & 0xFF


  String result;
  result += "OK CL ";
  result += frame->ID;
  result += " 0 ";

  // Temperature
  int temp = (int)(frame->Temperature * 10 + 1000);
  result += (byte)(temp >> 8);
  result += " ";
  result += (byte)(temp);
  result += " ";

  // Voltage
  result += (int)(frame->Voltage * 10);
  result += " ";

  // Frequency
  result += (byte)(frame->Frequency >> 24);
  result += " ";
  result += (byte)(frame->Frequency >> 16);
  result += " ";
  result += (byte)(frame->Frequency >> 8);
  result += " ";
  result += (byte)(frame->Frequency & 0xFF);
  result += " ";

  return result;
}



