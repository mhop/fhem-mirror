#include "RFMxx.h"

void RFMxx::SetPin(byte pin, bool value) {
  if (m_pinCallback) {
    m_pinCallback(2, pin, value);
  }
  else {
    digitalWrite(pin, value);
  }
}

void RFMxx::Receive() {
  if (IsRF69) {
    if (ReadReg(REG_IRQFLAGS2) & RF_IRQFLAGS2_PAYLOADREADY) {
      for (int i = 0; i < PAYLOADSIZE; i++) {
        byte bt = GetByteFromFifo();
        m_payload[i] = bt;
      }
      m_payloadReady = true;
    }
  }
  else {
    bool hasData = false;
    SetPin(m_ss, LOW);
    asm("nop");
    asm("nop");
    if (digitalRead(m_miso)) {
      hasData = true;
    }

    SetPin(m_ss, HIGH);
    if (hasData) {
      m_payload[m_payloadPointer++] = GetByteFromFifo();
      m_lastReceiveTime = millis();
    }

    if ((m_payloadPointer > 0 && millis() > m_lastReceiveTime + 50) || m_payloadPointer >= 32) {
      m_payloadReady = true;
    }
  }
}

void RFMxx::GetPayload(byte *data) {
  m_payloadReady = false;
  m_payloadPointer = 0;
  for (int i = 0; i < PAYLOADSIZE; i++) {
    data[i] = m_payload[i];
  }
}


void RFMxx::SetDataRate(unsigned long dataRate) {
  m_dataRate = dataRate;

  if (IsRF69) {
    word r = ((32000000UL + (m_dataRate / 2)) / m_dataRate);
    WriteReg(0x03, r >> 8);
    WriteReg(0x04, r & 0xFF);
  }
  else {
    byte bt = (byte)(round(344828.0 / m_dataRate)) - 1;
    RFMxx::spi16(0xC600 | bt);
  }
}


void RFMxx::SetFrequency(unsigned long kHz) {
  m_frequency = kHz;

  if (IsRF69) {
    unsigned long f = (((kHz * 1000) << 2) / (32000000L >> 11)) << 6;
    WriteReg(0x07, f >> 16);
    WriteReg(0x08, f >> 8);
    WriteReg(0x09, f);
  }
  else {
    RFMxx::spi16(40960 + (m_frequency - 860000) / 5);
  }

}

void RFMxx::EnableReceiver(bool enable){
  if (enable) {
    if (IsRF69) {
      WriteReg(REG_OPMODE, (ReadReg(REG_OPMODE) & 0xE3) | RF_OPMODE_RECEIVER);
    }
    else {
      spi16(0x82C8);
      spi16(0xCA81);
      spi16(0xCA83);
    }
  }
  else {
    if (IsRF69) {
      WriteReg(REG_OPMODE, (ReadReg(REG_OPMODE) & 0xE3) | RF_OPMODE_STANDBY);
    }
    else {
      spi16(0x8208);
    }
  }
  ClearFifo();
}

void RFMxx::EnableTransmitter(bool enable){
  if (enable) {
    if (IsRF69) {
      WriteReg(REG_OPMODE, (ReadReg(REG_OPMODE) & 0xE3) | RF_OPMODE_TRANSMITTER);
    }
    else {
      spi16(0x8238);
    }
  }
  else {
    if (IsRF69) {
      WriteReg(REG_OPMODE, (ReadReg(REG_OPMODE) & 0xE3) | RF_OPMODE_STANDBY);
    }
    else {
      spi16(0x8208);
    }
  }
}

byte RFMxx::GetByteFromFifo() {
  return IsRF69 ? ReadReg(0x00) : (byte)spi16(0xB000);
}

bool RFMxx::PayloadIsReady() {
  return m_payloadReady;
}


void RFMxx::ClearFifo() {
  if (IsRF69) {
    WriteReg(REG_IRQFLAGS2, 16);
  }
  else {
    for (byte i = 0; i < PAYLOADSIZE; i++) {
      spi16(0xB000);
    }
  }

}

void RFMxx::PowerDown(){
  if (IsRF69) {
    WriteReg(REG_OPMODE, (ReadReg(REG_OPMODE) & 0xE3) | RF_OPMODE_SLEEP);
  }
  else {
    spi16(0x8201);
  }
}

void RFMxx::InitializeLaCrosse() {
  if (IsRF69) {
    /* 0x01 */ WriteReg(REG_OPMODE, RF_OPMODE_SEQUENCER_ON | RF_OPMODE_LISTEN_OFF | RF_OPMODE_STANDBY);
    /* 0x02 */ WriteReg(REG_DATAMODUL, RF_DATAMODUL_DATAMODE_PACKET | RF_DATAMODUL_MODULATIONTYPE_FSK | RF_DATAMODUL_MODULATIONSHAPING_00);
    /* 0x05 */ WriteReg(REG_FDEVMSB, RF_FDEVMSB_90000);
    /* 0x06 */ WriteReg(REG_FDEVLSB, RF_FDEVLSB_90000);
    /* 0x11 */ WriteReg(REG_PALEVEL, RF_PALEVEL_PA0_ON | RF_PALEVEL_PA1_OFF | RF_PALEVEL_PA2_OFF | RF_PALEVEL_OUTPUTPOWER_11111);
    /* 0x13 */ WriteReg(REG_OCP, RF_OCP_OFF);
    /* 0x19 */ WriteReg(REG_RXBW, RF_RXBW_DCCFREQ_010 | RF_RXBW_MANT_16 | RF_RXBW_EXP_2);
    /* 0x28 */ WriteReg(REG_IRQFLAGS2, RF_IRQFLAGS2_FIFOOVERRUN);
    /* 0x29 */ WriteReg(REG_RSSITHRESH, 220);
    /* 0x2E */ WriteReg(REG_SYNCCONFIG, RF_SYNC_ON | RF_SYNC_FIFOFILL_AUTO | RF_SYNC_SIZE_2 | RF_SYNC_TOL_0);
    /* 0x2F */ WriteReg(REG_SYNCVALUE1, 0x2D);
    /* 0x30 */ WriteReg(REG_SYNCVALUE2, 0xD4);
    /* 0x37 */ WriteReg(REG_PACKETCONFIG1, RF_PACKET1_CRCAUTOCLEAR_OFF);
    /* 0x38 */ WriteReg(REG_PAYLOADLENGTH, PAYLOADSIZE);
    /* 0x3C */ WriteReg(REG_FIFOTHRESH, RF_FIFOTHRESH_TXSTART_FIFONOTEMPTY | RF_FIFOTHRESH_VALUE);
    /* 0x3D */ WriteReg(REG_PACKETCONFIG2, RF_PACKET2_RXRESTARTDELAY_2BITS | RF_PACKET2_AUTORXRESTART_ON | RF_PACKET2_AES_OFF);
    /* 0x6F */ WriteReg(REG_TESTDAGC, RF_DAGC_IMPROVED_LOWBETA0);
  }
  else {
    spi16(0x8208);   // RX/TX off
    spi16(0x80E8);   // 80e8 CONFIGURATION EL,EF,868 band,12.5pF  (iT+ 915  80f8)
    spi16(0xC26a);   // DATA FILTER
    spi16(0xCA12);   // FIFO AND RESET  8,SYNC,!ff,DR 
    spi16(0xCEd4);   // SYNCHRON PATTERN  0x2dd4 
    spi16(0xC481);   // AFC "Keep the F-Offset only during VDI=high" 
    spi16(0x94a0);   // RECEIVER CONTROL VDI Medium 134khz LNA max DRRSI 103 dbm  
    spi16(0xCC77);   // 
    spi16(0x9850);   // 0x9850: Shift positive,  Deviation 90 kHz 
    spi16(0xE000);   // 
    spi16(0xC800);   // 
    spi16(0xC040);   // 1.66MHz,2.2V 
  }

  ClearFifo();
}

void RFMxx::InitializePCA301() {
  /*
     PCA      LGW
     0x94C5                 // RX: LNA Gain Max / Pin VDI / Bandwidth 67kHz  / VDI FAST / DRSSI -73dBm
              0x94a0        // RX: LNA Gain Max / Pin VDI / Bandwidth 134kHz / VDI FAST / DRSSI -103dBm
     
     0xCA83                 // FIFO: INT Level 8 / Sync 2 Byte / FillStart=Sync / Sens low  /  Enabled
              0xCA12        // FIFO: INT Level 1 / Sync 2 Byte / FillStart=Sync / Sens high / Enabled
              
     0xC477                 // AFC: Enabled / once after power up  / Limit +3..-4         / High Accuracy     / Enable  frequenct offset register / no strobe
              0xC481        // AFC: Enabled / only during VDI=high / Limit no restriction / NO High Accuracy  / Disable frequenct offset register / no strobe
              
     0xC2AF                 // Filter Digital / Recovery Auto    / Quality Tresh. 7 / Recovery Slow
              0xC26a        // Filter Digital / Recovery Manuell / Quality Tresh. 0 / Recovery Fast
     
     
  */
  
  if (IsRF69) {
    WriteReg(REG_FDEVMSB, RF_FDEVMSB_45000);
    WriteReg(REG_FDEVLSB, RF_FDEVLSB_45000);
    WriteReg(REG_PALEVEL, RF_PALEVEL_PA0_ON | RF_PALEVEL_OUTPUTPOWER_10110);
  }
  else {
    spi16(0x982);   // deviation 45 kHz positive
  }

  SetFrequency(868950);
  SetDataRate(6631);
  

}

void RFMxx::InitializeEC3000() {
  if (IsRF69) {
    /* 0x01 */ WriteReg(REG_OPMODE, RF_OPMODE_SEQUENCER_ON | RF_OPMODE_LISTEN_OFF | RF_OPMODE_STANDBY);
    /* 0x02 */ WriteReg(REG_DATAMODUL, RF_DATAMODUL_DATAMODE_PACKET | RF_DATAMODUL_MODULATIONTYPE_FSK | RF_DATAMODUL_MODULATIONSHAPING_00);
    /* 0x05 */ WriteReg(REG_FDEVMSB, RF_FDEVMSB_20000);
    /* 0x06 */ WriteReg(REG_FDEVLSB, RF_FDEVLSB_20000);
    /* 0x11 */ WriteReg(REG_PALEVEL, RF_PALEVEL_PA0_ON | RF_PALEVEL_PA1_OFF | RF_PALEVEL_PA2_OFF | RF_PALEVEL_OUTPUTPOWER_11111);
    /* 0x13 */ WriteReg(REG_OCP, RF_OCP_OFF);
    /* 0x19 */ WriteReg(REG_RXBW, RF_RXBW_DCCFREQ_010 | RF_RXBW_EXP_3);
    /* 0x19 */ WriteReg(REG_AFCBW, RF_AFCBW_DCCFREQAFC_010 | RF_AFCBW_EXPAFC_2);
    /* 0x28 */ WriteReg(REG_IRQFLAGS2, RF_IRQFLAGS2_FIFOOVERRUN);
    /* 0x29 */ WriteReg(REG_RSSITHRESH, 220);
    /* 0x2E */ WriteReg(REG_SYNCCONFIG, RF_SYNC_ON | RF_SYNC_SIZE_5);
    /* 0x2F */ WriteReg(REG_SYNCVALUE1, 0x13);
    /* 0x30 */ WriteReg(REG_SYNCVALUE2, 0xF1);
    /* 0x31 */ WriteReg(REG_SYNCVALUE3, 0x85);
    /* 0x32 */ WriteReg(REG_SYNCVALUE4, 0xD3);
    /* 0x33 */ WriteReg(REG_SYNCVALUE5, 0xAC);
    /* 0x37 */ WriteReg(REG_PACKETCONFIG1, RF_PACKET1_CRCAUTOCLEAR_OFF);
    /* 0x38 */ WriteReg(REG_PAYLOADLENGTH, PAYLOADSIZE);
    /* 0x3C */ WriteReg(REG_FIFOTHRESH, RF_FIFOTHRESH_TXSTART_FIFONOTEMPTY | RF_FIFOTHRESH_VALUE);
    /* 0x3D */ WriteReg(REG_PACKETCONFIG2, RF_PACKET2_RXRESTARTDELAY_2BITS | RF_PACKET2_AUTORXRESTART_ON | RF_PACKET2_AES_OFF);
    /* 0x6F */ WriteReg(REG_TESTDAGC, RF_DAGC_IMPROVED_LOWBETA0);
  }

}

void RFMxx::InitializeElero() {
  WriteReg(REG_OPMODE, RF_OPMODE_SEQUENCER_ON | RF_OPMODE_LISTEN_OFF | RF_OPMODE_STANDBY);
  WriteReg(REG_DATAMODUL, RF_DATAMODUL_DATAMODE_PACKET | RF_DATAMODUL_MODULATIONTYPE_FSK | RF_DATAMODUL_MODULATIONSHAPING_00);
  WriteReg(REG_FDEVMSB, RF_FDEVLSB_35000);
  WriteReg(REG_FDEVLSB, RF_FDEVLSB_35000);
  WriteReg(REG_PALEVEL, RF_PALEVEL_PA0_ON | RF_PALEVEL_PA1_OFF | RF_PALEVEL_PA2_OFF | RF_PALEVEL_OUTPUTPOWER_11111);
  WriteReg(REG_OCP, RF_OCP_OFF);
  WriteReg(REG_RXBW, RF_RXBW_DCCFREQ_010 | RF_RXBW_EXP_3);
  WriteReg(REG_AFCBW, RF_AFCBW_DCCFREQAFC_010 | RF_AFCBW_EXPAFC_2);
  WriteReg(REG_IRQFLAGS2, RF_IRQFLAGS2_FIFOOVERRUN);
  WriteReg(REG_RSSITHRESH, 220);
  WriteReg(REG_SYNCCONFIG, RF_SYNC_ON | RF_SYNC_SIZE_2);
  WriteReg(REG_SYNCVALUE1, 0xD3);
  WriteReg(REG_SYNCVALUE2, 0x91);
  WriteReg(REG_PREAMBLELSB, 0xAA);
  WriteReg(REG_PREAMBLEMSB, 0xAA);
  WriteReg(REG_PACKETCONFIG1, RF_PACKET1_CRCAUTOCLEAR_OFF);
  WriteReg(REG_PAYLOADLENGTH, PAYLOADSIZE);
  WriteReg(REG_FIFOTHRESH, RF_FIFOTHRESH_TXSTART_FIFONOTEMPTY | RF_FIFOTHRESH_VALUE);
  WriteReg(REG_PACKETCONFIG2, RF_PACKET2_RXRESTARTDELAY_2BITS | RF_PACKET2_AUTORXRESTART_ON | RF_PACKET2_AES_OFF);
  WriteReg(REG_TESTDAGC, RF_DAGC_IMPROVED_LOWBETA0);

  SetFrequency(869525);
  SetDataRate(76767);

}


void RFMxx::SetHFParameter(byte address, byte value) {
  WriteReg(address, value);
  if (m_debug) {
    Serial.print("WriteReg:");
    Serial.print(address);
    Serial.print("->");
    Serial.print(value);
  }
}

void RFMxx::SetHFParameter(unsigned short value) {
  spi16(value);
  if (m_debug) {
    Serial.print("spi16:");
    Serial.print(value);
  }
}

int RFMxx::GetRSSI(bool doTrigger) {
  int rssi = -1024;
  if (IsRF69) {
    if (doTrigger) {
      WriteReg(REG_RSSICONFIG, RF_RSSI_START);
      unsigned long to = millis() + 100;
      while ((ReadReg(REG_RSSICONFIG) & RF_RSSI_DONE) == 0x00 && millis() < to);
    }
    rssi = -ReadReg(REG_RSSIVALUE);
    rssi >>= 1;
  }  

  return rssi;
}

byte RFMxx::spi8(byte value) {
  for (byte i = 8; i; i--) {
    digitalWrite(m_sck, LOW);
    if (value & 0x80) {
      digitalWrite(m_mosi, HIGH);
    }
    else {
      digitalWrite(m_mosi, LOW);
    }
    value <<= 1;
    digitalWrite(m_sck, HIGH);
    if (digitalRead(m_miso)) {
      value |= 1;
    }
  }
  digitalWrite(m_sck, LOW);

  return value;
}


unsigned short RFMxx::spi16(unsigned short value) {
  SetPin(m_ss, LOW);

  for (byte i = 0; i < 16; i++) {
    if (value & 32768) {
      digitalWrite(m_mosi, HIGH);
    }
    else {
      digitalWrite(m_mosi, LOW);
    }
    value <<= 1;
    if (digitalRead(m_miso)) {
      value |= 1;
    }
    digitalWrite(m_sck, HIGH);
    delayMicroseconds(1);
    digitalWrite(m_sck, LOW);
  }

  SetPin(m_ss, HIGH);
  return value;
}


byte RFMxx::ReadReg(byte addr) {
  SetPin(m_ss, LOW);
  SPI.transfer(addr & 0x7F);
  byte result = SPI.transfer(0);
  SetPin(m_ss, HIGH);
  return result;
}

void RFMxx::WriteReg(byte addr, byte value) {
  SetPin(m_ss, LOW);
  SPI.transfer(addr | 0x80);
  SPI.transfer(value);
  SetPin(m_ss, HIGH);
}

RFMxx::RadioType RFMxx::GetRadioType() {
  return m_radioType;
}

String RFMxx::GetRadioName() {
  switch (GetRadioType()) {
  case RFMxx::RFM12B:
    return String("RFM12");
    break;
  case RFMxx::RFM69CW:
    return String("RFM69");
    break;
  default:
    return String("None");
  }
}

bool RFMxx::IsConnected() {
  return m_radioType != RFMxx::None;
}

RFMxx::RFMxx(byte mosi, byte miso, byte sck, byte ss, byte irq, TPinCallback pinFunction) {
  m_mosi = mosi;
  m_miso = miso;
  m_sck = sck;
  m_ss = ss;
  m_irq = irq;

  m_debug = false;
  m_dataRate = 17241;
  m_frequency = 868300;
  m_payloadPointer = 0;
  m_lastReceiveTime = 0;
  m_payloadReady = false;
  m_radioType = RFMxx::None;

  pinMode(m_mosi, OUTPUT);
  pinMode(m_miso, INPUT);
  pinMode(m_sck, OUTPUT);

  m_pinCallback = pinFunction;
  if (!m_pinCallback) {
    pinMode(m_ss, OUTPUT);
    digitalWrite(m_ss, HIGH);
  }
  
}

bool RFMxx::Begin(bool isPrimary) {
  // No radio found until now
  m_radioType = RFMxx::None;

  if (m_pinCallback) {
    m_pinCallback(1, m_ss, OUTPUT);
    m_pinCallback(2, m_ss, HIGH);
  }

  // Is there a RFM69 ?
  WriteReg(REG_PAYLOADLENGTH, 0xA);
  if (ReadReg(REG_PAYLOADLENGTH) == 0xA) {
    WriteReg(REG_PAYLOADLENGTH, 0x40);
    if (ReadReg(REG_PAYLOADLENGTH) == 0x40) {
      m_radioType = RFMxx::RFM69CW;
    }
  }

  // Is there a RFM12 ?
  if (m_radioType == RFMxx::None) {
    if (isPrimary) {
      m_radioType = RFMxx::RFM12B;
    }
    else {
      spi16(0x820C); // Osc. + LBD
      for (int i = 0; i < 1000; i++) {
        asm("nop");
      }

      spi16(0xC04F); // LBD=3.7V
      for (int i = 0; i < 1000; i++) {
        asm("nop");
      }
      if ((spi16(0x0000) & 0x0400) == 0x0400) {
        spi16(0xC040);  // LBD = 2.2V
        for (int i = 0; i < 1000; i++) {
          asm("nop");
        }

        if ((spi16(0x0000) & 0x0400) == 0) {
          m_radioType = RFMxx::RFM12B;
        }
      }
      
      spi16(0xC040); // LBD = 2.2V
    }
  }
  
  if (m_radioType != RFMxx::None) {
    EnableReceiver(false);
  }

  return true;
}

void RFMxx::SetDebugMode(boolean mode) {
  m_debug = mode;
}
unsigned long RFMxx::GetDataRate() {
  return m_dataRate;
}

unsigned long RFMxx::GetFrequency() {
  return m_frequency;
}
void RFMxx::SendByte(byte data) {
  unsigned long to = millis() + 10;
  while (!(spi16(0x0000) & 0x8000) && millis() < to) {}
  RFMxx::spi16(0xB800 | data);
}


void RFMxx::SendArray(byte *data, byte length) {
  if (IsRF69) {
    WriteReg(REG_PACKETCONFIG2, (ReadReg(REG_PACKETCONFIG2) & 0xFB) | RF_PACKET2_RXRESTART); // avoid RX deadlocks
    EnableReceiver(false);
    ClearFifo();
    noInterrupts();
    SetPin(m_ss, LOW);
    SPI.transfer(REG_FIFO | 0x80);
    for (byte i = 0; i < length; i++) {
      SPI.transfer(data[i]);
    }

    SetPin(m_ss, HIGH);
    interrupts();

    EnableTransmitter(true);

    // Wait until transmission is finished
    unsigned long txStart = millis();
    while (!(ReadReg(REG_IRQFLAGS2) & RF_IRQFLAGS2_PACKETSENT) && millis() - txStart < 30);
    
    EnableTransmitter(false);
  }
  else {
    // Transmitter on
    EnableTransmitter(true);

    // Sync, sync, sync ...
    RFMxx::SendByte(0xAA);
    RFMxx::SendByte(0xAA);
    RFMxx::SendByte(0xAA);
    RFMxx::SendByte(0x2D);
    RFMxx::SendByte(0xD4);

    // Send the data
    for (int i = 0; i < length; i++) {
      RFMxx::SendByte(data[i]);
    }

    // Transmitter off
    delay(1);
    EnableTransmitter(false);

  }

  if (m_debug) {
    Serial.print("Sending data: ");
    for (int p = 0; p < length; p++) {
      Serial.print(data[p], DEC);
      Serial.print(" ");
    }
    Serial.println();
  }
}

