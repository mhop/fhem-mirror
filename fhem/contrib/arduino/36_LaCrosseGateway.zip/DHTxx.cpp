#include "DHTxx.h"

DHTxx::DHTxx() {

}

bool DHTxx::TryInitialize(byte pin, byte type) {
  m_pin = pin;
  m_type = type;

  return Read();
}

double DHTxx::GetTemperature() {
  return ((int)(m_temperature * 10)) / 10.0;
}

double DHTxx::GetHumidity() {
  return round(m_humidity);
}

bool DHTxx::TryMeasure() {
  bool result = false;
  
  if (Read()) {
    if(m_type == 22) {
      // DHT22
      m_humidity = word(m_data[0], m_data[1]) * 0.1;
      m_temperature = word(m_data[2] & 0x7F, m_data[3]) * 0.1;
      if (m_data[2] & 0x80) {
        m_temperature = -m_temperature;
      }
    }
    else {  
      // DHT11
      m_humidity    = m_data[0];
      m_temperature = m_data[2];
    }

    byte CheckSum;
    if(m_type == 22) {
      // DHT22
      CheckSum = m_data[0] + m_data[1] + m_data[2] + m_data[3];
    }
    else {
      // DHT11
      CheckSum = m_data[0] + m_data[2];
    }
    if (m_data[4] == CheckSum) {
      result = true;
    }
    
  }
  
  return result;
}

bool DHTxx::Read() {
  unsigned int to = F_CPU / 40000;
  byte mask = 128;
  byte idx = 0;

  for (byte i=0; i < 5; i++) {
    m_data[i] = 0;
  }

  // Ask him
  pinMode(m_pin, OUTPUT);
  digitalWrite(m_pin, LOW);
  delay(m_type == 22 ? 1 : 18);
  digitalWrite(m_pin, HIGH);
  delayMicroseconds(40);
  pinMode(m_pin, INPUT);

  unsigned int loopCnt = to;
  while(digitalRead(m_pin) == LOW) {
    if (--loopCnt == 0) {
      return false;
    }
  }

  loopCnt = to;
  while(digitalRead(m_pin) == HIGH) {
    if (--loopCnt == 0) {
      return false;
    }
  }

  for (byte i = 40; i != 0; i--) {
    loopCnt = to;
    while(digitalRead(m_pin) == LOW) {
      if (--loopCnt == 0) {
        return false;
      }
    }

    uint32_t t = micros();

    loopCnt = to;
    while(digitalRead(m_pin) == HIGH) {
      if (--loopCnt == 0) {
        return false;
      }
    }

    if ((micros() - t) > 40) { 
      m_data[idx] |= mask;
    }
    mask >>= 1;
    if (mask == 0) {
      mask = 128;
      idx++;
    }
  }
  pinMode(m_pin, OUTPUT);
  digitalWrite(m_pin, HIGH);

  return true;
}



