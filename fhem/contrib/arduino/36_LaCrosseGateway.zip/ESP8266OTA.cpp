#include "ESP8266OTA.h"


ESP8266OTA::ESP8266OTA() {
  m_log = "";
}

void ESP8266OTA::Log(String text, bool newLine) {
  m_log += text + (newLine ? "\n" : "");
  Serial.print(text + (newLine ? "\r\n" : ""));
}

void ESP8266OTA::Begin(ESP8266WebServer *server) {
  m_server = server;
  m_log = "";

  m_server->on("/ota/firmware.bin", HTTP_POST, [this]() {
    m_server->sendHeader("Connection", "close");
    m_server->sendHeader("Access-Control-Allow-Origin", "*");
    Log("");
    Log(Update.hasError() ? "ERROR: OTA update failed" : "OTA update finished");
    m_server->send(200, "text/plain", m_log);
    ESP.restart();
  }, [this]() {
    HTTPUpload &upload = m_server->upload();
    if (upload.status == UPLOAD_FILE_START){
      WiFiUDP::stopAll();
      m_log = "";
      Log("Start receiving '", false);
      Log(upload.filename, false);
      Log("'");
      uint32_t maxSketchSpace = (ESP.getFreeSketchSpace() - 0x1000) & 0xFFFFF000;
      if (!Update.begin(maxSketchSpace)){
        Update.printError(Serial);
        Log("ERROR: UPLOAD_FILE_START");
      }
    }
    else if (upload.status == UPLOAD_FILE_WRITE){
      if (Update.write(upload.buf, upload.currentSize) != upload.currentSize){
        Update.printError(Serial);
        Log("ERROR: UPLOAD_FILE_WRITE");
      }
    }
    else if (upload.status == UPLOAD_FILE_END){
      if (Update.end(true)) { 
        Log("Firmware size: ", false);
        Log(String(upload.totalSize));
        Log("Rebooting ESP8266 ...");
      }
      else {
        Update.printError(Serial);
        Log("ERROR: UPLOAD_FILE_END");
      }
    }
    yield();
  });


}


