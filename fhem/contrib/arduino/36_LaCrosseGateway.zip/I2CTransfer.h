#ifndef _I2CTRANSFER_h
#define _I2CTRANSFER_h

#include "Arduino.h"
#include "Wire.h"

typedef void ReceivedCallbackType(String);

static ReceivedCallbackType* I2CTransferReceiveCallback;
static String I2CTransferData;

class I2CTransfer{
public:
  I2CTransfer(byte ownAddress, byte partnerAddress, byte ledPin = 0);
  void Begin();
  void Send(String data);
  void SetReceiveCallback(ReceivedCallbackType* callback);


private:
  byte m_ownAddress;
  byte m_partnerAddress;
  byte m_packageLength;
  byte m_ledPin;

  void FlashLED();
};



#endif

