#ifndef _HTML_h
#define _HTML_h

#include "arduino.h"
#include "ESP8266WiFi.h"

class HTML {
public:
  static String Unescape(String escaped);
  static IPAddress IPAddressFromString(String ipString);

protected:


};


#endif

