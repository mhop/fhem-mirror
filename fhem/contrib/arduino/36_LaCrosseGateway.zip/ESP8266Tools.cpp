#include "ESP8266Tools.h"


ESP8266Tools::ESP8266Tools(byte ledPin) {
  m_ledPin = ledPin;
  m_ledEnabled = true;
}

void ESP8266Tools::SwitchLed(boolean on, bool force) {
  if (m_ledEnabled || force) {
    pinMode(m_ledPin, OUTPUT);
    digitalWrite(m_ledPin, !on);
  }
}

void ESP8266Tools::Blink(byte ct, bool force) {
  if (m_ledEnabled || force) {
    for (int i = 0; i < ct; i++) {
      SwitchLed(true, force);
      delay(50);
      SwitchLed(false, force);
      if (ct > 1) {
        delay(50);
      }
    }
  }

}

void ESP8266Tools::EnableLED(bool enable) {
  m_ledEnabled = enable;

  if (!m_ledEnabled) {
    SwitchLed(false);
  }

}


void ESP8266Tools::InitOTA(uint port) {
  m_ota.begin(port);
}

void ESP8266Tools::HandleOTA() {
  int cb = m_ota.parsePacket();
  if (cb) {
    IPAddress remote = m_ota.remoteIP();
    int cmd = m_ota.parseInt();
    int port = m_ota.parseInt();
    int sz = m_ota.parseInt();
    Serial.println("OTA update ...");
    Serial.print("from: ");
    Serial.print(remote);
    Serial.print(":");
    Serial.println(port);
    Serial.printf("cmd=%d size=%d Bytes\r\n", cmd, sz);
    WiFiClient cl;
    if (!cl.connect(remote, port)) {
      Serial.println("failed to connect");
      return;
    }

    m_ota.stop();

    if (!ESP.updateSketch(cl, sz)) {
      Serial.println("Update failed");
    }
  }
}