#ifndef _ADDONSERIALBASE_H
#define _ADDONSERIALBASE_H

#include "Arduino.h"
#include "ESP8266WiFi.h"
#include "WiFiClient.h"
#include "SC16IS750.h"


class AddOnSerialBase {
public:
  AddOnSerialBase(SC16IS750 *expander, byte dtrPort);
  typedef void LogItemCallbackType(String, bool);
  void Reset();
  void SetLogItemCallback(LogItemCallbackType callback);
  void Begin();
  void SetBaudrate(unsigned long baudrate);
  

protected:
  SC16IS750 *m_expander;
  bool m_doLogging;
  String m_log;
  LogItemCallbackType *m_logItemCallback;
  byte m_dtrPort;
  void Log(String text, bool newLine = true);

};


#endif

