#ifndef _STATEMANAGER_h
#define _STATEMANAGER_h

#include "Arduino.h"
#include "HashMap.h"
#include "Settings.h"

#define TIMES_SIZE 200

class StateManager {
 private:
   unsigned long m_lastKVPUpdate = 0;
   unsigned long m_lastFullKVPUpdate = 0;
   unsigned long m_times[TIMES_SIZE];
   bool m_debug;
   String m_version;
   unsigned long m_receivedFrames = 0;
   unsigned int m_framesPerMinute = 0;
   HashMap<String, String, 20> m_values;
   bool m_roolOverIsPossible = false;
   unsigned int m_uptimeDays = 0;
   Settings m_settings;

   void Update();

   
 public:
   StateManager();
   void SetDebugMode(boolean mode);
   void Begin(String version);
   String GetHTML();
   String GetXML();
   String GetKVP(bool full=true);
   String GetKVP(uint interval);
   String GetVersion();
   void Handle(byte receivedPackets);
   void ResetLastFullKVPUpdate();
   
   
};

#endif

