#include "HTML.h"


String HTML::Unescape(String escaped) {
  String result = "";
  for (unsigned int i = 0; i < escaped.length(); i++) {
    if (escaped[i] != '%') {
      result += escaped[i];
    }
    else {
      String specialChar = escaped.substring(i +1, i +3);
      result += (char)strtol(specialChar.c_str(), NULL, 16);
      i += 2;
    }
  }
  return result;
}


IPAddress HTML::IPAddressFromString(String ipString) {
  byte o1p = ipString.indexOf(".", 0);
  byte o2p = ipString.indexOf(".", o1p + 1);
  byte o3p = ipString.indexOf(".", o2p + 1);
  byte o4p = ipString.indexOf(".", o3p + 1);

  return IPAddress(strtol(ipString.substring(0, o1p).c_str(), NULL, 10),
    strtol(ipString.substring(o1p + 1, o2p).c_str(), NULL, 10),
    strtol(ipString.substring(o2p + 1, o3p).c_str(), NULL, 10),
    strtol(ipString.substring(o3p + 1, o4p).c_str(), NULL, 10));
}

