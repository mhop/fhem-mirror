#include "I2CTransfer.h"

void I2CTransferReceiveHandler(int count) {
  if (count == 1) {
    byte bt = Wire.read();
    if (bt == 0) {
      I2CTransferData = "";
    }
    else if (bt == 1) {
      if (I2CTransferData == "RESET") {
        #ifndef ESP8266
          asm volatile ("  jmp 0");
        #endif
      }
      else {
        I2CTransferReceiveCallback(I2CTransferData);
      }
    }
    else {
      I2CTransferData += (char)bt;
    }
  }
  else {
    for (int i = 0; i < count; i++) {
      I2CTransferData += (char)Wire.read();
    }
  }

}

void I2CTransfer::SetReceiveCallback(ReceivedCallbackType* callback) {
  I2CTransferReceiveCallback = callback;
}


I2CTransfer::I2CTransfer(byte ownAddress, byte partnerAddress, byte ledPin) {
  m_ownAddress = ownAddress;
  m_partnerAddress = partnerAddress;
  m_ledPin = ledPin;
  m_packageLength = 16;
}

void I2CTransfer::Begin() {
  Wire.begin(m_ownAddress);
  Wire.onReceive(I2CTransferReceiveHandler);
  /// ToDo
  Serial.println("I2CTransfer::Begin()");
}

void I2CTransfer::Send(String data) {
  Wire.beginTransmission(m_partnerAddress);
  Wire.write(0);
  Wire.endTransmission(true);

  uint16_t transmitted = 0;
  while (data.length()){
    Wire.beginTransmission(m_partnerAddress);
    Wire.write(data.substring(0, min(data.length(), m_packageLength - 1)).c_str());
    data = data.substring(min(data.length(), m_packageLength - 1));
    Wire.endTransmission(true);
  }

  Wire.beginTransmission(m_partnerAddress);
  Wire.write(1);
  Wire.endTransmission(true);

  FlashLED();
}


void I2CTransfer::FlashLED() {
  if (m_ledPin > 0) {
    pinMode(m_ledPin, OUTPUT);
    digitalWrite(m_ledPin, HIGH);
    delay(50);
    digitalWrite(m_ledPin, LOW);
  }
}
