#ifndef _PCA301_h
#define _PCA301_h

#include "Arduino.h"
#include "RFMxx.h"

class PCA301 {
public:
  struct Frame {
    byte Channel;
    byte Command;
    byte ID1;
    byte ID2;
    byte ID3;
    byte data;
    float Power;
    float AccumulatedPower;
    word CRC;
    bool IsValid;
  };
  
  PCA301();
  void SetDebugMode(boolean mode);
  void Begin(RFMxx *rfm);
  void Handle();
  String GetFhemDataString();
  static const byte FRAME_LENGTH = 12;
  static word CalculateCRC(byte data[]);
  static void EncodeFrame(struct PCA301::Frame *frame, byte bytes[5]);
  static void DecodeFrame(byte *bytes, struct PCA301::Frame *frame);
  static bool TryHandleData(byte *data);
  static String GetFhemDataString(byte *data);
  static bool IsValidDataRate(unsigned long dataRate);

protected:
  bool m_debug;
  RFMxx *m_rfm;

  static String BuildFhemDataString(struct PCA301::Frame *frame);
};


#endif

