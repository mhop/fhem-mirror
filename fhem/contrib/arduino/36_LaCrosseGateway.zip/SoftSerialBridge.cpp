#include "SoftSerialBridge.h"

SoftSerialBridge::SoftSerialBridge() : m_wifiServer(0), m_softSerial(D4, D3) {
  m_isConnected = false;
  m_connectCallback = nullptr;
  m_progressCallback = nullptr;
  m_enabled = false;
  m_tcpPort = 0;
}

void SoftSerialBridge::Begin(uint tcpPort, unsigned long baud, ESP8266WebServer *webServer) {
  m_tcpPort = tcpPort;
  m_webServer = webServer;
  
  m_wifiServer = WiFiServer(m_tcpPort);
  m_wifiServer.begin();
  m_wifiServer.setNoDelay(true);

  m_softSerial.Begin(baud);
  
  m_enabled = true;
}

void SoftSerialBridge::Handle() {
  if (m_wifiServer.hasClient()) {
    m_isConnected = true;
    m_client.stop();
    m_client = m_wifiServer.available();
    m_client.setNoDelay(true);
    delay(250);

    if (m_connectCallback) {
      m_connectCallback(true);
    }
  }
  if (!m_client.connected()) {
    if (m_isConnected) {
      if (m_connectCallback) {
        m_connectCallback(false);
      }
    }
    m_isConnected = false;
  }
 
  if (m_client.available()) {
    while (m_client.available()) {
      int bt = m_client.read();
      m_softSerial.Write(bt);
    }
  }
  
  if (m_softSerial.Available()) {
    byte bt = m_softSerial.Read();
    m_client.write(bt);
  }
}

void SoftSerialBridge::SetConnectCallback(ConnectCallbackType * callback) {
  m_connectCallback = callback;
}

ESP8266SoftSerial * SoftSerialBridge::GetSoftSerial() {
  return &m_softSerial;
}

void SoftSerialBridge::SetProgressCallback(ProgressCallbackType * callback) {
  m_progressCallback = callback;
}

uint SoftSerialBridge::GetPort() {
  return m_tcpPort;
}

bool SoftSerialBridge::IsEnabled() {
  return m_enabled;
}

bool SoftSerialBridge::IsConnected() {
  return m_isConnected;
}







