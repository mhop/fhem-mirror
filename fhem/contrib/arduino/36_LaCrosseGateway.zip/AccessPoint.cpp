#include "AccessPoint.h"

AccessPoint::AccessPoint(IPAddress ip, IPAddress gateway, IPAddress subnet, String ssidPrefix) {
  m_ip = ip;
  m_gateway = gateway;
  m_subnet = subnet;
  m_ssidPrefix = ssidPrefix;
}

void AccessPoint::Begin(int autoClose) {
  if (m_debug) {
    Serial.println("Starting Access point");
  }
  WiFi.mode(WiFiMode::WIFI_AP_STA);
  WiFi.softAPConfig(m_ip, m_ip, m_subnet);
  String ssid = m_ssidPrefix + "_" + String((unsigned int)ESP.getChipId());
  char char_array[ssid.length() + 1];
  ssid.toCharArray(char_array, ssid.length() + 1);
  WiFi.softAP(char_array);

  if (m_debug) {
    Serial.println("Access point running: " + ssid);
  }

  m_autoClose = autoClose;
  m_startMillis = millis();
  m_running = true;
}

void AccessPoint::End() {
  if (m_debug) {
    Serial.println("Closing Access point");
  }
  m_running = false;
  m_autoClose = 0;
  WiFi.mode(WiFiMode::WIFI_STA);
  
  if (m_debug) {
    Serial.println("Access point closed");
  }
}

void AccessPoint::Handle() {
  if(m_autoClose > 0 && m_running) {
    if(millis() - m_startMillis > m_autoClose * 1000) {
      End();
    }
  } 
}

void AccessPoint::SetDebugMode(boolean mode) {
  m_debug = mode;
}