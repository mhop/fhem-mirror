#ifndef __BME280_H__
#define __BME280_H__

#include "Arduino.h"
#include "I2CBase.h"


enum {
  BME280_REGISTER_T1              = 0x88,
  BME280_REGISTER_T2              = 0x8A,
  BME280_REGISTER_T3              = 0x8C,

  BME280_REGISTER_P1              = 0x8E,
  BME280_REGISTER_P2              = 0x90,
  BME280_REGISTER_P3              = 0x92,
  BME280_REGISTER_P4              = 0x94,
  BME280_REGISTER_P5              = 0x96,
  BME280_REGISTER_P6              = 0x98,
  BME280_REGISTER_P7              = 0x9A,
  BME280_REGISTER_P8              = 0x9C,
  BME280_REGISTER_P9              = 0x9E,

  BME280_REGISTER_H1              = 0xA1,
  BME280_REGISTER_H2              = 0xE1,
  BME280_REGISTER_H3              = 0xE3,
  BME280_REGISTER_H4              = 0xE4,
  BME280_REGISTER_H5              = 0xE5,
  BME280_REGISTER_H6              = 0xE7,

  BME280_REGISTER_CHIPID          = 0xD0,
  BME280_REGISTER_VERSION         = 0xD1,
  BME280_REGISTER_SOFTRESET       = 0xE0,

  BME280_REGISTER_CAL26           = 0xE1,

  BME280_REGISTER_CONTROLHUMID    = 0xF2,
  BME280_REGISTER_CONTROL         = 0xF4,
  BME280_REGISTER_CONFIG          = 0xF5,
  BME280_REGISTER_PRESSUREDATA    = 0xF7,
  BME280_REGISTER_TEMPDATA        = 0xFA,
  BME280_REGISTER_HUMIDDATA       = 0xFD,
};

typedef struct {
  uint16_t T1;
  int16_t  T2;
  int16_t  T3;

  uint16_t P1;
  int16_t  P2;
  int16_t  P3;
  int16_t  P4;
  int16_t  P5;
  int16_t  P6;
  int16_t  P7;
  int16_t  P8;
  int16_t  P9;

  uint8_t  H1;
  int16_t  H2;
  uint8_t  H3;
  int16_t  H4;
  int16_t  H5;
  int8_t   H6;
} bme280_compensation;

class BME280 : public I2CBase {
public:
  BME280();
  void SetAltitudeAboveSeaLevel(int altitude);
  bool  TryInitialize(byte address);
  float GetTemperature();
  int GetPressure();
  int GetHumidity();

protected:
  void ReadCompensation();

  int m_altitudeAboveSeaLevel;
  int32_t m_compensatedTemperature;
  bme280_compensation m_compensation;

};

#endif
