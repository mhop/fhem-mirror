#ifndef _OLED_h
#define _OLED_h

#include <Arduino.h>
#include <Wire.h>
#include "OLEDFonts.h"
class OLED {

public:
  enum Orientations {
    Normal,
    UpsideDown
  };
  enum Alignments {
    Left,
    Center,
    Right
  };

  enum Colors {
    White,
    Black,
    Invert
  };

private:
   int m_address;
   byte m_buffer[128 * 64 / 8];
   const char *m_font = Roboto_Light_11;

public:
  OLED();
  bool Begin(byte address, Orientations orientation);
  void On();
  void Off();
  void Clear();
  void Refresh();
  void SetContrast(byte contrast);
  void Command(byte command);
  void SetFont(const char *fontData);
  void Print(int x, int y, String text, Alignments alignment = Alignments::Left);
  void DrawXBM(int x, int y, int width, int height, const char *xbm);
  void SetPixel(int x, int y, Colors color);
  void DrawRect(int x, int y, int width, int height, bool fill = false, Colors color = Colors::White);
  void DrawBitmap(int x, int y, int width, int height, const char *bitmap);
  int GetStringWidth(String text);

};

#define CHARGEPUMP 0x8D
#define COLUMNADDR 0x21
#define COMSCANDEC 0xC8
#define COMSCANINC 0xC0
#define DISPLAYALLON 0xA5
#define DISPLAYALLON_RESUME 0xA4
#define DISPLAYOFF 0xAE
#define DISPLAYON 0xAF
#define EXTERNALVCC 0x1
#define INVERTDISPLAY 0xA7
#define MEMORYMODE 0x20
#define NORMALDISPLAY 0xA6
#define PAGEADDR 0x22
#define SEGREMAP 0xA0
#define SETCOMPINS 0xDA
#define SETCONTRAST 0x81
#define SETDISPLAYCLOCKDIV 0xD5
#define SETDISPLAYOFFSET 0xD3
#define SETHIGHCOLUMN 0x10
#define SETLOWCOLUMN 0x00
#define SETMULTIPLEX 0xA8
#define SETPRECHARGE 0xD9
#define SETSEGMENTREMAP 0xA1
#define SETSTARTLINE 0x40
#define SETVCOMDETECT 0xDB
#define SWITCHCAPVCC 0x2

#endif