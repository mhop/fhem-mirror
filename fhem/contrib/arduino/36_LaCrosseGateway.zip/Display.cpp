#include "Display.h"
#include "XBM.h"
#include "ESP8266WiFi.h"

Display::Display() {
  m_isConnected = false;
  m_lastUpdate = 0;
}

bool Display::IsConnected() {
  return m_isConnected;
}

bool Display::Begin(StateManager *stateManager) {
  byte address = 0x3C;
  m_stateManager = stateManager;

  m_isConnected = m_display.Begin(address, OLED::Orientations::UpsideDown);

  if(m_isConnected) {
    m_display.Clear();
    m_display.On();

    m_display.SetFont(Roboto_Light_15);
    m_display.Print(64, Y2, "LGW V" + m_stateManager->GetVersion(), OLED::Alignments::Center);
    
    m_display.Refresh();
    m_display.SetFont(Roboto_Light_13);
  }

  return m_isConnected;
}

void Display::SetWifiFlag(bool flag) {
  if (flag) {
    m_display.DrawXBM(0, 0, xbm_wifi_width, xbm_wifi_height, xbm_wifi_bits);
  }
  else {
    m_display.DrawRect(0, 0, xbm_wifi_width, xbm_wifi_height, true, OLED::Colors::Black);
  }

  m_display.Refresh();
}

void Display::SetFhemFlag(bool flag) {
  if (flag) {
    m_display.DrawXBM(24, 0, xbm_fhem_width, xbm_fhem_height, xbm_fhem_bits);
  }
  else {
    m_display.DrawRect(24, 0, xbm_fhem_width, xbm_fhem_height, true, OLED::Colors::Black);
  }

  m_display.Refresh();
}

void Display::SetAddonFlag(bool flag) {
  if (flag) {
    m_display.DrawXBM(48, 0, xbm_cpu_width, xbm_cpu_height, xbm_cpu_bits);
  }
  else {
    m_display.DrawRect(48, 0, xbm_cpu_width, xbm_cpu_height, true, OLED::Colors::Black);
  }

  m_display.Refresh();
}

void Display::SetRSSI(int rssi) {
  m_display.DrawRect(65, 0, 128, 15, true, OLED::Colors::Black);
  String text;
  text += rssi;
  text += " dBm";
  m_display.Print(127, 0, text, OLED::Alignments::Right);

  m_display.Refresh();
}

void Display::SetLED(bool show) {
  m_display.DrawRect(65, 0, 128, 15, true, OLED::Colors::Black);
  if (show) {
    m_display.DrawRect(115, 1, 128, 14, true, OLED::Colors::White);
  }
  m_display.Refresh();
}

void Display::ShowProgress(unsigned int maxValue, String message) {
  m_maxProgress = maxValue;
  m_currentProgress = 0;

  Print(message, 1, OLED::Alignments::Center);
  m_display.DrawRect(0, 34, 127, 16, true, OLED::Colors::Black);
  m_display.DrawRect(0, 36, 127, 12, false);
  
  Print("0%", 3, OLED::Alignments::Center);
  m_display.Refresh();
}

void Display::MoveProgress() {
  m_currentProgress++;
  byte percent = (float)((float)m_currentProgress / (float)m_maxProgress) * 100;
  byte width = percent * 1.24;

  m_display.DrawRect(2, 38, width, 9, true);
  Print(String(percent) + "%", 3, OLED::Alignments::Center);
  m_display.Refresh();
}

void Display::HideProgress() {
  m_display.DrawRect(0, 18, 128, 45, true, OLED::Colors::Black);
  m_display.Refresh();
}



void Display::Print(String text, byte line, OLED::Alignments alignment) {
  m_display.DrawRect(0, 18 + 17 * --line, 128, 16, true, OLED::Colors::Black);

  byte xPos = 0;
  if (alignment == OLED::Alignments::Center) {
    xPos = 64;
  }
  else if (alignment == OLED::Alignments::Right) {
    xPos = 127;
  }

  m_display.SetFont(Roboto_Light_13);
  m_display.Print(xPos, 18 + 16 * line, text, alignment);
  m_display.Refresh();
}

void Display::Command(String command) {
  /*
  t: Temperature
  h: Humidity
  p: Pressure
  s: State
  f: FHEM-Message
 
  set myJeeLink raw "OLED slide=20"
  set myJeeLink raw "OLED mode=ths"
  set myJeeLink raw "OLED mode=thp"
  set myJeeLink raw "OLED On"
  set myJeeLink raw "OLED Off"
  set myJeeLink raw "OLED mode=f"
  set myJeeLink raw "OLED print=Hi from FHEM\nCoffe is cold\n(27 �C)"
  */

  Serial.println(command);

  if (command == "Off") {
    m_display.Off();
  }
  else {
    m_display.On();
  }

  int pos = command.indexOf('=');
  if (pos != -1) {
    String value = command.substring(pos +1);
    command = command.substring(0, pos);
    command.toLowerCase();

    String test;
    test += "Cmd:";
    test += command;
    test += " Value:";
    test += value;
    Print(test, 3);

    if (command == "mode") {
 
    }
    
    else if (command == "slide") {

    }
    
    else if (command == "print") {

    }

  }


}

void Display::Handle() {
  if (IsConnected()) {
    if (millis() < m_lastUpdate) {
      m_lastUpdate = 0;
    }
    if (millis() > m_lastUpdate + 1000) {
      SetRSSI(WiFi.RSSI());
      
      m_lastUpdate = millis();
    }

  }
}

void Display::Clear() {
  m_display.Clear();
}



