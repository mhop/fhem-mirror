#include "PCA301.h"

/*
  868.950 MHz / 6.631 kbps
  
  TX protocol (display unit):
  TX: 01 04 07 F8 92 00 AA AA AA AA 71 52
  TX: 01 04 07 F8 92 00 AA AA AA AA 71 52
  TX: 01 05 07 F8 92 01 AA AA AA AA 77 4A

  RX protocol (display unit):
  RX: 01 04 07 F8 92 00 00 00 00 00 0E 9F
  RX: 01 04 07 F8 92 01 00 00 00 00 8E E4
  RX: 01 05 07 F8 92 01 AA AA AA AA 77 4A
  
  Pairing:
  Outlet: 00 11 07 F9 2F AA AA AA AA AA crc crc
  Basw:   04 04 07 F9 2F 00 AA AA AA AA crc crc
  Outlet: 04 04 07 F9 2F 00 00 00 00 00 crc crc

         0  1  3  3  4  5  6  7  8  9 10 11
        ----------------------------------- 
        01 05 07 F8 92 01 AA AA AA AA 77 4A
        |  |  -------- |  ----- ----- -----  
        |  |     |     |    |     |     |------ CRC16 (Polynom 8005h)
        |  |     |     |    |     |  
        |  |     |     |    |     |------------ Accumulated consumption kWh 1/100
        |  |     |     |    |    
        |  |     |     |    |------------------ current consumption W 1/100
        |  |     |     |    
        |  |     |     |----------------------- data: 0/1 for command 5 or 1 with command 4
        |  |     |
        |  |     |----------------------------- address
        |  |
        |  |----------------------------------- command: 04=measure data, 05=switch device, 06=device LED, 11=pairing
        |
        |-------------------------------------- channel
 
 */
 
PCA301::PCA301() {
  m_debug = false;
  m_rfm == NULL;
}

void PCA301::SetDebugMode(boolean mode) {
  m_debug = mode;
}

void PCA301::Begin(RFMxx *rfm) {
  m_rfm = rfm;
}

bool PCA301::IsValidDataRate(unsigned long dataRate) {
  return dataRate == 6631ul;
}

void PCA301::Handle() {
  if(m_rfm != NULL) {

  }
}

void PCA301::EncodeFrame(struct PCA301::Frame *frame, byte bytes[FRAME_LENGTH]) {
  for (int i = 0; i < FRAME_LENGTH; i++) { 
    bytes[i] = 0; 
  }
  
}

void PCA301::DecodeFrame(byte *bytes, struct PCA301::Frame *frame) {
  frame->IsValid = false;
  
  if(bytes[0] == 1) {
    Serial.print("PCA301: ");
    for (int i = 0; i < PCA301::FRAME_LENGTH; i++) {
      Serial.print(bytes[i], HEX);
      Serial.print(" ");
    }
    Serial.println();
  
    word crc = CalculateCRC(bytes);
    Serial.print("CRC: ");
    Serial.print((byte)(crc >> 8), HEX);
    Serial.print(" ");
    Serial.println((byte)(crc & 0xFF), HEX);

  }
  
  
}

String PCA301::BuildFhemDataString(struct PCA301::Frame *frame) {
  String result = "";
  
  return result;
}

String PCA301::GetFhemDataString(byte *data) {
  String result = "";

  struct PCA301::Frame frame;
  DecodeFrame(data, &frame);
  if (frame.IsValid) {
    result = BuildFhemDataString(&frame);
  }

  return result;
}

word PCA301::CalculateCRC(byte data[]) {
  word result = 0;
  int i, j;
  for (j = 0; j < PCA301::FRAME_LENGTH -2; j++) {
    result = result ^ ((uint16_t)data[j] << 8);
    for (i = 0; i<8; i++) {
      if (result & 0x8000) {
        result = (result << 1) ^ 0x8005;
      }
      else {
        result <<= 1;
      }
    }
  }
  return result;
}


