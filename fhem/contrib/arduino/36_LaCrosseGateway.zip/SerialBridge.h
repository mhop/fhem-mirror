#ifndef _SERIALBRIDGE_H
#define _SERIALBRIDGE_H

#include "AddOnSerialBase.h"

typedef void ConnectCallbackType();

class SerialBridge : public AddOnSerialBase {
public:
  SerialBridge(SC16IS750 *expander, byte dtrPort);
  void Begin(uint tcpPort);
  void Handle();
  void SetConnectCallback(ConnectCallbackType* callback);

private:
  uint m_tcpPort;
  WiFiServer m_server;
  WiFiClient m_client;
  ConnectCallbackType *m_ConnectCallback;
};


#endif

