#ifndef _DATAFRAME_h
#define _DATAFRAME_h

#include "Arduino.h"

class CapacitiveLevelFrame {
public:
  struct Frame {
    byte  Header;
    byte  ID;
    float Temperature;
    float Voltage;
    uint32_t Frequency; // 0 to 4.294.967.295
    byte Debug1;
    byte Debug2;
    byte Debug3;
    byte Debug4;
    uint16_t CRC;
    bool  IsValid;
  };
  static const byte FRAME_LENGTH = 14;
  static const byte FRAME_HEADER = 12;
  static void EncodeFrame(struct Frame *frame, byte *bytes);
  static void DecodeFrame(byte *data, struct Frame *frame);
  static String AnalyzeFrame(Frame *frame);
  static String AnalyzeFrame(byte *data);
  static bool TryHandleData(byte *data);
  static String GetFhemDataString(byte *data);
  static bool IsValidDataRate(unsigned long dataRate);
  static uint16_t CalculateCRC16(byte *data, byte len);
  static void SetDebugMode(boolean mode);


protected:
  static String BuildFhemDataString(struct CapacitiveLevelFrame::Frame *frame);
  static bool m_debug;

};

#endif

