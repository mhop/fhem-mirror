#ifndef _SOFTSERIALBRIDGE_H
#define _SOFTSERIALBRIDGE_H

#include "Arduino.h"
#include "ESP8266SoftSerial.h"
#include "ESP8266WiFi.h"
#include "WiFiClient.h"
#include "ESP8266WebServer.h"

typedef void ConnectCallbackType(bool isConnected);
typedef void ProgressCallbackType(byte action, unsigned long offset, unsigned long maxValue, String message);

class SoftSerialBridge {
public:
  SoftSerialBridge();
  void Begin(uint tcpPort, unsigned long baud, ESP8266WebServer *webServer);
  void Handle();
  uint GetPort();
  bool IsEnabled();
  bool IsConnected();
  void SetProgressCallback(ProgressCallbackType* callback);
  void SetConnectCallback(ConnectCallbackType* callback);
  ESP8266SoftSerial *GetSoftSerial();

private:
  bool m_enabled;
  uint m_tcpPort;
  ESP8266WebServer *m_webServer;
  WiFiServer m_wifiServer;
  WiFiClient m_client;
  bool m_isConnected;

  ConnectCallbackType *m_connectCallback;
  ProgressCallbackType *m_progressCallback;
  ESP8266SoftSerial m_softSerial;

};


#endif

