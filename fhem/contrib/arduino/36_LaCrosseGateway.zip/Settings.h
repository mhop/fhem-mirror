#ifndef _SETTINGS_h
#define _SETTINGS_h

#include "arduino.h"
#include "HashMap.h"

#define EEPROM_SIZE 1024

class Settings {
public:
  Settings();
  static void SetDebugMode(boolean mode);

  void Read();
  void Write();
  void Dump();

  String Get(String key, String defaultValue);
  int GetInt(String key, int defaultValue);

  void Add(String key, String value);


private:
  HashMap<String, String, 20> m_data;
  static bool m_debug;
};





#endif

