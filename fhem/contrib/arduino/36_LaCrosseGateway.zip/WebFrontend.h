#ifndef _WEBFRONTEND_h
#define _WEBFRONTEND_h

#include "Arduino.h"
#include "ESP8266WiFi.h"
#include "WiFiClient.h"
#include "ESP8266WebServer.h"
#include "StateManager.h"

class WebFrontend {
 public:
   WebFrontend(int port);
   void Handle();
   void Begin(StateManager *stateManager);
   void SetDebugMode(boolean mode);
   ESP8266WebServer *WebServer();

private:
  int m_port;
  ESP8266WebServer m_webserver;
  bool m_debug;
  StateManager *m_stateManager;
  String GetNavigation();
  String GetTop();
  String GetBottom();
  String GetRedirectToRoot(String message = "");
   
};

#endif

