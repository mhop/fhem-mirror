#ifndef _WEBFRONTEND_h
#define _WEBFRONTEND_h

#include "Arduino.h"
#include "ESP8266WiFi.h"
#include "StateManager.h"

class WebFrontend {
 private:
   int m_port;
   WiFiServer m_webserver;
   bool m_debug;
   StateManager *m_stateManager;

   String GetNavigation();
   
 public:
   WebFrontend(int port);
   void Handle();
   void Begin(StateManager *stateManager);
   void SetDebugMode(boolean mode);

  
   
};

#endif

