#ifndef ESP8266TOOLS_H
#define ESP8266TOOLS_H

#include "Arduino.h"
#include "WiFiUDP.h"
#include "ESP8266WiFi.h"

class ESP8266Tools {
public:
  ESP8266Tools(byte ledPin);
  void Blink(byte ct, bool force=false);
  void EnableLED(bool enable);
  void InitOTA(uint port = 8266);
  void HandleOTA();
  void SwitchLed(boolean on, bool force=false);

private:
  byte m_ledPin;
  bool m_ledEnabled;
  WiFiUDP m_ota;
  uint m_otaPort;
  
};


#endif

