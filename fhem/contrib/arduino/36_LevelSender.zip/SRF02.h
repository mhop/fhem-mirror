#ifndef _SRF02_h
#define _SRF02_h

#include <Wire.h>
#include <Arduino.h>

#define SRF_MODE_INCHES       0x50
#define SRF_MODE_CENTIMETERS  0x51
#define SRF_MODE_MICROSECONDS 0x52
#define SRF_COMMAND_REGISTER  0x00
#define SRF_RESULT_REGISTER   0x02
        
class SRF02 {
public:  
  SRF02(byte address, byte mode);
  float ReadDistance();

private:
  byte m_Address;	
  byte m_Mode;

};


#endif

