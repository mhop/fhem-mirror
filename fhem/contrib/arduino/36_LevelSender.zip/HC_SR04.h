#ifndef _HC_SR04_h
#define _HC_SR04_h

#include "Arduino.h"

class HC_SR04 {
public:  
  HC_SR04(byte triggerPin, byte echoPin);
  float ReadDistance(float temperature = 20.0);

private:
  byte m_TriggerPin, m_EchoPin;  
};


#endif

