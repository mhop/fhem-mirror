#ifndef _POWERSAVE_h
#define _POWERSAVE_h

#include "Arduino.h"

class PowerSaveClass {
 
public:
  void Sleep(unsigned long milliseconds);

private:
  void InternalSleep(byte duration);

};

extern PowerSaveClass PowerSave;

#endif

