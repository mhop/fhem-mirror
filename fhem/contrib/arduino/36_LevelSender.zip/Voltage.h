#ifndef _VOLTAGE_h
#define _VOLTAGE_h

#include "Arduino.h"

class Voltage {
public:  
  enum ReferenceVoltages {
    ReferenceVoltage11 = 1,
    ReferenceVoltage33 = 3,
    ReferenceVoltage50 = 5
  };


  Voltage(byte pin, ReferenceVoltages referenceVolatage, float voltageDivider, int readings = 1);
  float ReadVoltage();

private:
  byte m_Pin;
  int m_Readings;
  float m_ReferenceVoltage;
  float m_voltageDivider;
  
};


#endif

