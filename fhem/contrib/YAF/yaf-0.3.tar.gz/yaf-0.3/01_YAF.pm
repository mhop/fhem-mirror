########################################################################################
#
# 01_YAF.pm
#
# YAF - Yet Another Floorplan
# FHEM Projektgruppe Hochschule Karlsruhe, 2013
# Markus Mangei, Daniel Weisensee
#
########################################################################################
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
########################################################################################
package main;

use JSON::XS;
use strict;
use warnings;
use lib qw(YAF);
use YAF::YAFWidgets;
use YAF::YAFConfig;
 
use vars qw(%data);
use vars qw(%_GET);
use vars qw(%defs);
use vars qw($FW_cname);
use vars qw($FW_RET);
use vars qw($FW_dir);  

sub YAF_Request($@); 

my $fhem_url;
my $yafw_encoding = "UTF-8";				# Encoding
my $yaf_www_directory = "./FHEM/YAF/www";

YAFConfig();

sub YAF_Initialize ($) {
	my ($hash) = @_;
	
	$hash->{DefFn} = "YAF_define";
	
	# http://fhemurl:fhemport/YAF wird von diesem Modul verarbeitet.
	# Bei jedem Aufruf wird die Funktion YAF_Request() aufgerufen.
	my $name = "YAF";
	$fhem_url = "/" . $name;
	$data{FWEXT}{$fhem_url}{FUNC} = "YAF_Request";
	$data{FWEXT}{$fhem_url}{LINK} = "YAF/www/global/yaf.htm";
	$data{FWEXT}{$fhem_url}{NAME} = "YAF";
		
	# Widgets laden
	require_widgets();
	
}

sub YAF_Print($@) {
	if ($_[0]) {
		$FW_RET .= $_[0];	
	}
}

sub YAF_Clean() {
	$FW_RET = "";	
}

sub YAF_Load_Ressource($@) {
	my $absoluteFilePath = $_[0]; # /home/example_user/test.htm
	
	my $filebuffer = "";
	my $fh;
	
	# Filename
	my @absoluteFilePathSplitted = split(/\//, $absoluteFilePath);
	my $filename = $absoluteFilePathSplitted[scalar(@absoluteFilePathSplitted)-1];
	
	# Extention
	my @filenameSplitted = split(/\./, $filename);
	my $extention = $filenameSplitted[scalar(@filenameSplitted)-1];
	
	# Datei laden
	if ((-f $absoluteFilePath) && open($fh, "<", $absoluteFilePath)) {
		binmode $fh;
		my ($data, $n);
		while (($n = read $fh, $data, 4) != 0) {
			$filebuffer .= $data; 
		}
	}
	else {
		# Datei nicht gefunden
		return YAF_NotFound($absoluteFilePath);	
	}	
	close($fh);

	if ($extention eq "htm" || $extention eq "html") {	
		if ($filename eq "yaf.htm") {
			# replace:
			# ###widget_css###
			# ###widget_js###
			my $widget_css = get_widgets_css();
			my $widget_js = get_widgets_js();
			$filebuffer =~ s/###widget_css###/$widget_css/g;
			$filebuffer =~ s/###widget_js###/$widget_js/g;
		}
		YAF_Print($filebuffer);			
		return ("text/html; charset=$yafw_encoding", $FW_RET);
	}
	elsif ($extention eq "gif") {
		YAF_Print($filebuffer);			
		return ("image/gif; charset=$yafw_encoding", $FW_RET);		
	}
	elsif ($extention eq "jpg" || $extention eq "jpeg") {
		YAF_Print($filebuffer);			
		return ("image/jpeg; charset=$yafw_encoding", $FW_RET);			
	}	
	elsif ($extention eq "png") {
		YAF_Print($filebuffer);				
		return ("image/png; charset=$yafw_encoding", $FW_RET);			
	}	
	elsif ($extention eq "css") {
		YAF_Print($filebuffer);			
		return ("text/css; charset=$yafw_encoding", $FW_RET);			
	}		
	elsif ($extention eq "js") {
		YAF_Print($filebuffer);				
		return ("text/javascript; charset=$yafw_encoding", $FW_RET);			
	}		
	else {
		YAF_Print($filebuffer);			
		return ("text/plain; charset=$yafw_encoding", $FW_RET);		
	}
}



sub YAF_define ($@) {
	my ($hash, $def) = @_;
	return;
}

sub YAF_LoadView($@) {
	my ($view) = @_;
	YAF_Print("ddd");			
	return ("text/html; charset=$yafw_encoding", $FW_RET);	
}

sub YAF_Request ($@) {
	my ($htmlarg) = @_;
	# %20 durch Leerzeichen ersetzen
	$htmlarg =~ s/%20/ /g;
		
	# GET Parameter
	my @params = split(/\?/, $htmlarg);
	
	if (scalar(@params) > 1) {
		my @attributesArray = split("&",$params[1]);
		my @attributePair;
		for (my $i = 0; $i < scalar(@attributesArray); $i++) {
			@attributePair = split("=",$attributesArray[$i]);
			$_GET{$attributePair[0]} = $attributePair[1];
		}
	}
	
	@params = split(/\//, $params[0]);
	
	# Output bBuffer leeren
	YAF_Clean();

	# Url in Controller zerlegen
	my $controler_count = scalar(@params);
	
	# Nicht genügend Parameter
	# control_1 und control_2 müssen vorhanden sein!
	if ($controler_count > 3) {
		my $control_1 = "";
		$control_1 = $params[2];
		my $control_2 = "";
		$control_2 = $params[3];
		if ($control_1 eq "www") {
			if ($control_2 eq "global") {
				my $request_file = $yaf_www_directory;
				my $pos = 4;
				for (; $pos < scalar(@params); $pos++) {
					$request_file .= "/";
					$request_file .= $params[$pos];
				}
				# Ressource aus dem global www Verzeichnis laden
				return YAF_Load_Ressource($request_file);
			}
			elsif ($control_2 eq "widget") {
				return ("text/plain; charset=$yafw_encoding", $FW_RET);		
			}
			else {
				# Error: control_1 = www => control_2 = unbekannt
				return YAF_NotFound($htmlarg);	
			}
		}
		elsif ($control_1 eq "ajax") {
			if ($control_2 eq "global") {
				if ($controler_count > 4) {
					my $function = "";
					$function = $params[4];	
					if ($function eq "getViews") {
						my $views = encode_json(getViews());
						YAF_Print($views);	
					}
					# Fügt eine leere Sicht hinzu
					elsif ($function eq "addView") {
						if ($_GET{"name"} && (addView($_GET{"name"}) == 1)) { 
							YAF_Print("1");
						}
						else {
							YAF_Print("0");
						}
					}
					# Löscht eine View
					elsif ($function eq "deleteView") {
						if ($_GET{"id"} && (deleteView($_GET{"id"}) == 1)) { 
							YAF_Print("1");
						}
						else {
							YAF_Print("0");
						}
					}
					# Gibt alle Widgets zu einer Sicht aus
					elsif ($function eq "getView") {
						if ($_GET{"id"}) { 
							YAF_Print(encode_json(getView($_GET{"id"})));
						}
						else {
							YAF_Print("0");
						}	
					}
					# Ändetr den Namen einer Sicht
					elsif ($function eq "editView") {
						if ($_GET{"id"} && $_GET{"name"}) { 
							YAF_Print(editView($_GET{"id"}, $_GET{"name"}));
						}
						else {
							YAF_Print("0");
						}	
					}
					# Position eines Widgets ändern
					elsif ($function eq "setWidgetPosition") {
						if ($_GET{"view_id"} && $_GET{"widget_id"} && $_GET{"x_pos"} && $_GET{"y_pos"}) { 
							setWidgetPosition($_GET{"view_id"}, $_GET{"widget_id"}, $_GET{"x_pos"}, $_GET{"y_pos"});
							YAF_Print("1");
						}
						else {
							YAF_Print("0");
						}
					}	
					elsif ($function eq "getWidgets") {
						my @widgets = get_widget_array();
						YAF_Print(encode_json(\@widgets));
					}
					elsif ($function eq "addWidget") {
						if ($_GET{"view_id"} && $_GET{"widget"} && $_GET{"attributes"}) {
							# %22 wieder durch " ersetzen!
							# @TODO Probleme mit Sonderzeichen müssen noch behoben werden!
							$_GET{"attributes"} =~ s/%22/"/g;
							my @attributes_array = @{decode_json($_GET{"attributes"})};
							my $widgetId = addWidget($_GET{"view_id"},$_GET{"widget"}, 28, 69, \@attributes_array);
							YAF_Print($widgetId);	
						}
						else {
							YAF_Print("0");	
						}
					}
					elsif($function eq "deleteWidget"){
						if ($_GET{"view_id"} && $_GET{"widget_id"} && (deleteWidget($_GET{"view_id"}, $_GET{"widget_id"}) == 1)) { 
							YAF_Print("1");
						}
						else {
							YAF_Print("0");
						}
					}
					elsif($function eq "getRefreshTime"){
						my $refreshTime = getRefreshTime();
						YAF_Print($refreshTime);
					}
					elsif($function eq "setRefreshTime"){
						if($_GET{"interval"}){
							my $newRefreshTime = $_GET{"interval"};
							setRefreshTime($newRefreshTime);
							YAF_Print($newRefreshTime);
						} else{
							YAF_Print("0");
						}
					}
					else {
						YAF_Print("0");	
					}				
				}
				else {
					YAF_Print("1");	
				}
				return ("text/plain; charset=$yafw_encoding", $FW_RET);		
			}
			elsif ($control_2 eq "widget") {
				my $widget = "";
				$widget = $params[4];
				my $function = "";
				$function = $params[5];
				if ($widget ne "") {
					YAF_Print(eval($widget."_".$function."();")) or YAF_Print("0");
				}
				else {
					YAF_Print("0");	
				}
				return ("text/plain; charset=$yafw_encoding", $FW_RET);		
			}
			else {
				return YAF_NotFound($htmlarg);	
			}
		}
		else {
			# Error: control_1 = unbekannt
			return YAF_NotFound($htmlarg);	
		}
	}
	else {
		return YAF_NotFound($htmlarg);
	}
}

sub YAF_NotFound{
		# Datei nicht gefunden
		my $file = $_[0];
		
		YAF_Print("Error 404: $file");			
		YAF_Print("\n");	
		return ("text/html; charset=$yafw_encoding", $FW_RET);	
}

1;
