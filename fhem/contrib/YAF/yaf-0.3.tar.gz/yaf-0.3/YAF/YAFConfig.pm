########################################################################################
#
# YAFConfig.pm
#
# YAF - Yet Another Floorplan
# FHEM Projektgruppe Hochschule Karlsruhe, 2013
# Markus Mangei, Daniel Weisensee
#
########################################################################################
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
########################################################################################
package main;

use strict;
use warnings;
use XML::LibXML;
use XML::LibXML::PrettyPrint;

# Filepath to YAF configuration XML
my $configurationFilepath = "./FHEM/YAF/xml/yafConfig.xml";

# Filepath to the XML schema for validation
my $schemaFilepath = "./FHEM/YAF/xml/xmlSchema.xsd";

# The XML schema instance
my $xmlSchema;

# The pretty printer instance
my $prettyPrinter;

# The configuration instance
my $config;

##
# Initializes this module by creating the schema, pretty printer and loading the configuration from the filepath.
##
sub YAFConfig {
        $xmlSchema = XML::LibXML::Schema->new(location => $schemaFilepath);
        $prettyPrinter = XML::LibXML::PrettyPrint->new(indent_string => "  ");
       
        $config = XML::LibXML->load_xml(location => $configurationFilepath);
        validate();
}

##
# Validates the current state of the configuration instance.
# Is used to validate the coniguration before writing it to the XML file.
# Returns 1 if valid, otherwise 0.
##
sub validate{
	eval{ $xmlSchema->validate($config); };

	if($@){
		print("Error validate: configuration file is invalid!\n");
		## exit YAF?
		return 0;
	}
	return 1;
}

##
# Searches the defined views and returns a pointer to the resulting array of views.
##
sub getViews{
        my @views = $config->findnodes('//view');
        my @viewsArray;
        my $index = 0;
        
        foreach my $view (@views){
                $viewsArray[$index][0] = $view->findvalue('@id');
                $viewsArray[$index][1] = $view->findvalue('@name');             
                $index++; 
        }
        
        return \@viewsArray;
}

##
# Searches the view with the given view id and returns a pointer to the view hash.
#
# @param viewId The view id to search
# @return Pointer to the view hash, hash may be empty
##
sub getView{
        my $viewId = $_[0];
        
        my %viewHash = ();
        
        # query view id
        my $viewResult = $config->findnodes('//view[@id = '.$viewId.']');
        if($viewResult->size() == 1){
	        my $view = $viewResult->get_node(0);
	        
	        # prepare view hash and add simple key/value pairs (name)     
	        $viewHash{'name'} = $view->findvalue('@name');
	
	        # collect all widgets and add them to an array which is then connected to the view hash
	        my @widgetsArray = ();
	        my @widgets = $view->findnodes('widgets/widget');
	        
			foreach my $widget (@widgets){
	                my @attributes = $widget->attributes();
	                my %widgetHash = ();
	                
	                foreach my $attribute (@attributes){
	                        $widgetHash{$attribute->nodeName} = $attribute->getValue();
	                }
	                
				# collect attr nodes in a hash and add to widget
				my %attrHash = ();
				my @attrs = $widget->getChildrenByTagName('attr');
			
				foreach my $attr (@attrs){
					my $key = $attr->findvalue('@name');
					my $value = $attr->findvalue('@value');
					$attrHash{$key} = $value;
				}
				$widgetHash{'attr'} = \%attrHash;
			
			
				push(@widgetsArray, \%widgetHash);
	        }
	        $viewHash{'widgets'} = \@widgetsArray;
	        
	        # collect all backgrounds and add them to an array which is then connected to the view hash
	        my @backgroundsArray = ();
	        my @backgrounds = $view->findnodes('backgrounds/background');
	        
	        foreach my $background (@backgrounds){
	                my @attributes = $background->attributes();
	                my %backgroundHash = ();
	                
	                foreach my $attribute (@attributes){
	                        $backgroundHash{$attribute->nodeName} = $attribute->getValue();
	                }
	                
	                push(@backgroundsArray, \%backgroundHash);
	        }
	        $viewHash{'backgrounds'} = \@backgroundsArray;        	
       } else{
       	     print("Error getView: view with id = ".$viewId." was not found!\n");
       }
       
       return \%viewHash;
}

##
# Edits the view with the given id by changing its name to the specified value.
#
# @param viewId The view id to edit
# @param viewName The view name to be set
# @return 1 if successful, otherwise 0
##
sub editView{
        my $viewId = $_[0];
        my $viewName = $_[1];
        
        my $viewResult = $config->findnodes('//view[@id = '.$viewId.']');
        if($viewResult->size() == 1){
        	my $view = $viewResult->get_node(0);
        	$view->setAttribute('name', $viewName);
        	saveConfiguration();
        	return 1;
        } else {
        	print("Error editView: view with id = ".$viewId." was not found!\n");
        	return 0;
        }
}

##
# Deletes the view with the given id.
#
# @param viewId The view id to be deleted
# @return 1 if successful, otherwise 0
##
sub deleteView{
        my $viewId = $_[0];
        
        my $viewResult = $config->findnodes('//view[@id = '.$viewId.']');
        if($viewResult->size() == 1){
         	my $view = $viewResult->get_node(0);
	        my $views = $view->parentNode;
	        $views->removeChild($view);
	        saveConfiguration();
	        return 1;
        } else{
	        print("Error deleteView: view with id = ".$viewId." was not found!\n");
	        return 0;	
	    }
}

##
# Adds a new view with the specified name to the collection.
# The view has a default background image which can be changed by manipulating the path in the yafConfig.xml.
#
# @param viewName The view name of the new view
# @return 1
##
sub addView{
        my $viewName = $_[0];
        
        # determine id for new element
        my $newId = 0;
        my @views = $config->findnodes('//view');
        
        foreach my $view (@views){
                my $tempId = $view->findvalue('@id'); 
                
                if($newId < $tempId){
                        $newId = $tempId;
                }
        }
        $newId++;
        
        # initialize view and append to document
        my $view = $config->createElement('view');
        $view->setAttribute('id', $newId);
        $view->setAttribute('name', $viewName);
        # set default background
 		my $backgrounds = $config->createElement('backgrounds');
 		my $background = $config->createElement('background');
 		$background->setAttribute('img_url', "./img/eg.jpeg");
 		$background->setAttribute('x_pos', 1);
 		$background->setAttribute('y_pos', 1);
 		$backgrounds->appendChild($background);
 		$view->appendChild($backgrounds);
 		# initialize empty widgets node
 		my $widgets = $config->createElement('widgets');
 		$view->appendChild($widgets);
 		
 		# add new view to configuration
 		my $parent = $config->findnodes('//views')->get_node(0);
 		$parent->appendChild($view);
        
        saveConfiguration();
        return 1;
}

##
# Adds a new widget to the view defined by its id and adds the given properties to the new widget.
#
# @param viewId The view id to search
# @param widgetName The name of the new widget
# @param xPos The x coordinate of the widget position
# @param yPos The y coordinate of the widget position
# @param attributesArray The array of attribute elements
# @return The widget id if successful, otherwise 0
##
sub addWidget{
        my $viewId = $_[0];
        my $widgetName = $_[1];
        my $xPos = $_[2];
        my $yPos = $_[3];
        my @attributesArray = @{$_[4]};
        
        my $viewsResult = $config->findnodes('//view[@id = '.$viewId.']');
        if($viewsResult->size() == 1){
        	my $view = $viewsResult->get_node(0);
    
            # create a new widget with given properties
	        my $widget = $config->createElement('widget');
	        $widget->setAttribute('name', $widgetName);
	        $widget->setAttribute('x_pos', $xPos);
	        $widget->setAttribute('y_pos', $yPos);
	        my @widgets = $view->findnodes('widgets/widget');
	        my $newId = 0;
	        
	        foreach my $currentWidget (@widgets){
	                my $tempId = $currentWidget->findvalue('@id'); 
	                
	                if($newId < $tempId){
	                        $newId = $tempId;
	                }
	        }
	        $newId++;
	        $widget->setAttribute('id', $newId);
	        
	        # add widgets attribute nodes
	        foreach my $attribute (@attributesArray){
	        	my $attr = $config->createElement('attr'); 	
	            $attr->setAttribute('name', @$attribute[0]);
	       		$attr->setAttribute('value', @$attribute[1]);
	        	$widget->appendChild($attr);
	        }
	        
		    # append the new widget to the configuration
	        my $widgetsNode = $view->findnodes('widgets')->get_node(0);
	        $widgetsNode->appendChild($widget);
	        
	        saveConfiguration();
	        return $newId;   
        } else{
        	print("Error addWidget: view with id = ".$viewId." was not found!\n");
        	return 0;
        }
}

##
# Deletes the widget defined by its corresponding view id and widget id.
#
# @param viewId The view id the widget corresponds to
# @param widgetId The widget id of the widget to be deleted
# @return 1 if successful, otherwise 0
##
sub deleteWidget{
	my $viewId = $_[0];
	my $widgetId = $_[1];
	
	my $widgetResult = $config->findnodes('//view[@id = '.$viewId.']/widgets/widget[@id = '.$widgetId.']');
	if($widgetResult->size() == 1){
		my $widget = $widgetResult->get_node(0);
		my $widgets = $widget->parentNode;
		$widgets->removeChild($widget);
		
		saveConfiguration();
		return 1;
	} else{
		print("Error deleteWidget: widget with id = ".$widgetId." in view with id = ".$viewId." was not found!\n");
		return 0;	
	}
}

##
# Sets the position (x, y) of the widget defined by its corresponding view id and widget id to the given values.
#
# @param viewId The view id to search
# @param widgetId The widget id
# @param xPos The new x coordinate of the widget position
# @param yPos The new y coordinate of the widget position
# @return 1 if successful, otherwise 0
##
sub setWidgetPosition{
        my $viewId = $_[0];
        my $widgetId = $_[1];
        my $xPos = $_[2];
        my $yPos = $_[3];
        
        my $widgetResult = $config->findnodes('//view[@id = '.$viewId.']/widgets/widget[@id = '.$widgetId.']');
        if($widgetResult->size() == 1){
        	my $widget = $widgetResult->get_node(0);
	        $widget->setAttribute('x_pos', $xPos);
	        $widget->setAttribute('y_pos', $yPos);
	        
	        saveConfiguration();
	        return 1;
        } else{
        	print("Error setWidgetPosition: widget with id = ".$widgetId." in view with id = ".$viewId." was not found!\n");
        	return 0;
        }
}

##
# Searches the widget attribute properties of the specified widget.
#
# @param viewId The view id to search
# @param widgetId The widget id
# @param attributeName The name of the attribute properties to search for
# @return The value property if successful, otherwise 0
##
sub getWidgetAttribute{
	my $viewId = $_[0];
	my $widgetId = $_[1];
	my $attributeName = $_[2];
	
	my $attributes = $config->findnodes('//view[@id = '.$viewId.']/widgets/widget[@id = '.$widgetId.']/attr');
	
	foreach my $attr (@{$attributes}){
		if ($attr->getAttribute('name') eq $attributeName) {
			return $attr->getAttribute('value');
		}
	}
	# TODO
	# print("Error getWidgetAttribute: matching attribute was not found\n");
	return 0;
}

##
# Searches and returns the refresh time of the widgets.
# This value is an integer value and defines the time interval in seconds, after which the widgets update their state.
#
# @return The refresh time if successful, otherwise 0
##
sub getRefreshTime{
	my $refreshNodeResult = $config->findnodes('configuration/settings/refresh');
	if($refreshNodeResult->size() == 1){
		my $refreshNode = $refreshNodeResult->get_node(0);
		my $refreshTime = $refreshNode->getAttribute('interval');	
		return $refreshTime;
	} else{
		print("Error getRefreshTime: refresh node was not found\n");
		return 0;		
	}
}

##
# Sets the refresh time interval to the given value. The value gets checked as a positive integer value.
#
# @param newRefreshInterval The new refresh interval
# @return 1 if successful, otherwise 0
##
sub setRefreshTime{
	my $newRefreshInterval = $_[0];
	
	my $refreshNodeResult = $config->findnodes('configuration/settings/refresh');
	if(($newRefreshInterval =~ /^\d+$/) && ($refreshNodeResult->size() == 1)){
		my $refreshNode = $refreshNodeResult->get_node(0);
		$refreshNode->setAttribute('interval', $newRefreshInterval);
		
		saveConfiguration();
		return 1;		
	} else{
		print("Error setRefreshTime: no valid refresh value or refresh node was not found\n");
		return 0;	
	}
}

##
# Validates the configuration instance and in case of a valid configuration saves it to the underlying XML file
# in formatted (pretty printing) style.
#
# @return 1 if successful, otherwise 0
##
sub saveConfiguration{
	my $state = 0;
	
	if(validate() == 1){
        $prettyPrinter->pretty_print($config);
        $state = $config->toFile("$configurationFilepath");
	} else{
		print("Error saveConfiguration: validation failed");
	}
	return $state;
}

1;