Extract this archive into the FHEM installation directory (fhem-5.5 or higher
is needed).

Stop any existing fhem process first.
Start it with "perl fhem.pl fhem.cfg.demo"
It uses its own log-directory and configfile, so it won't overwrite any
settings in the original installation.
