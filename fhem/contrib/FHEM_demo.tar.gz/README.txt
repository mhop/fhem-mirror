Extract this archive into the FHEM installation directory (fhem-5.5 or higher
is needed).

Stop any existing fhem process first.
Start it with "perl fhem.pl fhem.cfg.demo"

The demo uses its own log-directory (demolog) and configfile (fhem.cfg.demo),
so it won't overwrite any settings in the original installation, which uses log
and fhem.cfg for the same purpose.
